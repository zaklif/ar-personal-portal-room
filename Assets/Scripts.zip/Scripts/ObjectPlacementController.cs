﻿
//using UnityEngine;
//using UnityEngine.XR.ARFoundation;
//using UnityEngine.XR.ARSubsystems;
//using System.Collections.Generic;
//using UnityEngine.InputSystem.EnhancedTouch;
//using TMPro;
//using UnityEngine.UI;
//using Touch = UnityEngine.InputSystem.EnhancedTouch.Touch;

//public class ObjectPlacementController : MonoBehaviour
//{
//    [Header("AR")]
//    [SerializeField] private ARRaycastManager arRaycastManager;

//    [Header("Prefab Objects")]
//    [SerializeField] private GameObject[] objectPrefabs;
//    [SerializeField] private string[] objectNames;

//    [Header("UI")]
//    [SerializeField] private GameObject bottomBar;
//    [SerializeField] private GameObject objectListPanel;
//    [SerializeField] private Transform listContent;
//    [SerializeField] private GameObject listItemPrefab;
//    [SerializeField] private GameObject confirmPanel;

//    [Header("Owner Edit/Delete Popup")]
//    [SerializeField] private GameObject editPopupPanel;
//    [SerializeField] private Button editButton;
//    [SerializeField] private Button deleteButton;
//    [SerializeField] private Button settingsButton;

//    [Header("Room Bounds")]
//    [SerializeField] private GameObject portalRoom;

//    [Header("Shelf Snapping")]
//    [SerializeField] private LayerMask shelfLayerMask;
//    [SerializeField] private float shelfSnapRayDistance = 5f;

//    [Header("Object Features")]
//    [SerializeField] private GameObject indicatorPrefab;
//    [SerializeField] private VisitorObjectPopup visitorPopup;
//    [SerializeField] private OwnerObjectSettings ownerSettings;

//    private List<ARRaycastHit> hits = new List<ARRaycastHit>();
//    private int selectedIndex = -1;
//    private bool isPlacingMode = false;
//    private bool isAdjustingMode = false;
//    private bool isVisitorMode = false;

//    private GameObject runtimeModelPrefab = null;
//    private string runtimeModelFileName = "";
//    private GameObject previewObject = null;

//    private float lastPinchDistance;
//    private float lastTwoFingerAngle;

//    private List<GameObject> placedObjects = new List<GameObject>();
//    private Dictionary<GameObject, string> objectFileNames = new Dictionary<GameObject, string>();
//    private GameObject currentlySelectedObject = null;
//    private List<GameObject> shelfObjects = new List<GameObject>();
//    private bool isPopupOpen = false;

//    void OnEnable() => EnhancedTouchSupport.Enable();
//    void OnDisable() => EnhancedTouchSupport.Disable();

//    void Start()
//    {
//        bottomBar.SetActive(false);
//        objectListPanel.SetActive(false);
//        confirmPanel.SetActive(false);
//        editPopupPanel.SetActive(false);
//        PopulateList();

//        if (editButton != null) { editButton.onClick.RemoveAllListeners(); editButton.onClick.AddListener(OnEditPopupPressed); }
//        if (deleteButton != null) { deleteButton.onClick.RemoveAllListeners(); deleteButton.onClick.AddListener(OnDeletePopupPressed); }
//        if (settingsButton != null) { settingsButton.onClick.RemoveAllListeners(); settingsButton.onClick.AddListener(OnSettingsPopupPressed); }
//    }

//    public void SetVisitorMode(bool visitor)
//    {
//        isVisitorMode = visitor;
//        if (visitor) { bottomBar.SetActive(false); editPopupPanel.SetActive(false); }
//    }

//    public void RegisterRestoredObject(GameObject obj, string fileName, PlacedObjectData data = null)
//    {
//        EnsureCollider(obj);
//        AttachMetaData(obj, fileName, data);
//        SpawnIndicator(obj);
//        placedObjects.Add(obj);
//        objectFileNames[obj] = fileName;
//        Debug.Log($"[OBJECT] Registered: {fileName} | name={data?.objectName} | type={data?.objectType}");
//    }

//    void AttachMetaData(GameObject obj, string fileName, PlacedObjectData data = null)
//    {
//        var meta = obj.GetComponent<ObjectMetaData>();
//        if (meta == null) meta = obj.AddComponent<ObjectMetaData>();

//        meta.Init(RoomManager.Instance?.CurrentRoom?.roomId ?? "");

//        if (data != null)
//        {
//            // Restore saved instanceId so updates work correctly
//            if (!string.IsNullOrEmpty(data.instanceId))
//                meta.instanceId = data.instanceId;

//            meta.objectName = data.objectName;
//            meta.description = data.description;
//            meta.objectType = (ObjectMetaData.ObjectType)data.objectType;
//            meta.price = data.price;
//            meta.currency = data.currency;
//        }
//        else
//        {
//            meta.objectName = System.IO.Path.GetFileNameWithoutExtension(fileName);
//        }
//    }

//    void SpawnIndicator(GameObject obj)
//    {
//        if (indicatorPrefab == null) return;
//        var meta = obj.GetComponent<ObjectMetaData>();
//        if (meta == null) return;
//        GameObject indicator = Instantiate(indicatorPrefab);
//        var indUI = indicator.GetComponent<ObjectIndicatorUI>();
//        if (indUI != null) indUI.SetTarget(obj.transform);
//        meta.SetIndicator(indicator);
//    }

//    // ── Popup handlers ────────────────────────────────────────────────────

//    void OnEditPopupPressed()
//    {
//        if (currentlySelectedObject == null) return;
//        ClosePopup();
//        BeginEditExistingObject(currentlySelectedObject);
//    }

//    void OnDeletePopupPressed()
//    {
//        if (currentlySelectedObject == null) return;
//        ClosePopup();
//        DeleteObject(currentlySelectedObject);
//    }

//    void OnSettingsPopupPressed()
//    {
//        if (currentlySelectedObject == null) return;

//        // FIX: close edit popup BEFORE opening settings
//        // prevents both being open at same time
//        ClosePopup();

//        var meta = currentlySelectedObject.GetComponent<ObjectMetaData>();
//        if (meta != null)
//        {
//            GameObject objRef = currentlySelectedObject;
//            ownerSettings?.Show(meta, () => SaveMetaToRoom(objRef));
//        }
//    }

//    void OpenPopup(GameObject obj)
//    {
//        // FIX: don't open if settings or visitor popup already open
//        if (ownerSettings != null && ownerSettings.IsOpen) return;

//        currentlySelectedObject = obj;
//        editPopupPanel.SetActive(true);
//        isPopupOpen = true;
//    }

//    void ClosePopup()
//    {
//        editPopupPanel.SetActive(false);
//        isPopupOpen = false;
//    }

//    public void SetPopupOpen(bool open) => isPopupOpen = open;
//    public void ShowBottomBar() => bottomBar.SetActive(true);
//    public void HideBottomBar() => bottomBar.SetActive(false);
//    public void SetPortalRoom(GameObject room) { portalRoom = room; }
//    public void RefreshShelfSurfaces(List<GameObject> shelves) { shelfObjects = new List<GameObject>(shelves); }

//    public void OnAddObjectButtonPressed()
//    {
//        if (isVisitorMode || !RoomInsideDetector.IsInsideRoom) return;
//        objectListPanel.SetActive(true);
//        bottomBar.SetActive(false);
//    }

//    void PopulateList()
//    {
//        foreach (Transform child in listContent) Destroy(child.gameObject);
//        for (int i = 0; i < objectPrefabs.Length; i++)
//        {
//            int index = i;
//            GameObject item = Instantiate(listItemPrefab, listContent);
//            item.GetComponentInChildren<TMP_Text>().text = objectNames[i];
//            item.GetComponent<Button>().onClick.AddListener(() => OnObjectSelected(index));
//        }
//    }

//    void OnObjectSelected(int index) { selectedIndex = index; isPlacingMode = true; objectListPanel.SetActive(false); }

//    public void SetRuntimeModel(GameObject model, string fileName = "")
//    {
//        runtimeModelPrefab = model;
//        runtimeModelFileName = fileName;
//        runtimeModelPrefab.SetActive(false);
//        isPlacingMode = true;
//        bottomBar.SetActive(false);
//    }

//    void Update()
//    {
//        var activeTouches = Touch.activeTouches;

//        if (isPlacingMode)
//        {
//            if (activeTouches.Count == 0) return;
//            var touch = activeTouches[0];
//            if (touch.phase != UnityEngine.InputSystem.TouchPhase.Began) return;
//            TryPlaceObject(touch.screenPosition);
//            return;
//        }

//        if (isAdjustingMode && previewObject != null) { HandleAdjustment(activeTouches); return; }

//        // FIX: also block tap if settings panel is open
//        if (!isPlacingMode && !isAdjustingMode && !isPopupOpen &&
//            !(ownerSettings != null && ownerSettings.IsOpen))
//        {
//            if (activeTouches.Count == 1)
//            {
//                var touch = activeTouches[0];
//                if (touch.phase == UnityEngine.InputSystem.TouchPhase.Began)
//                    TrySelectPlacedObject(touch.screenPosition);
//            }
//        }
//    }

//    void TryPlaceObject(Vector2 screenPos)
//    {
//        Vector3 spawnPos; Quaternion spawnRot;
//        if (TryRaycastShelf(screenPos, out Vector3 sp, out Quaternion sr)) { spawnPos = sp; spawnRot = sr; }
//        else if (arRaycastManager.Raycast(screenPos, hits, TrackableType.PlaneWithinPolygon)) { spawnPos = hits[0].pose.position; spawnRot = hits[0].pose.rotation; }
//        else
//        {
//            Vector3 fwd = Camera.main.transform.forward; fwd.y = 0; fwd.Normalize();
//            spawnPos = Camera.main.transform.position + fwd * 1.5f; spawnPos.y = 0f;
//            spawnRot = Quaternion.LookRotation(fwd, Vector3.up);
//        }
//        SpawnPreview(spawnPos, spawnRot);
//    }

//    bool TryRaycastShelf(Vector2 screenPos, out Vector3 hitPos, out Quaternion hitRot)
//    {
//        hitPos = Vector3.zero; hitRot = Quaternion.identity;
//        if (shelfObjects.Count == 0) return false;
//        Ray ray = Camera.main.ScreenPointToRay(screenPos);
//        if (Physics.Raycast(ray, out RaycastHit hit, shelfSnapRayDistance, shelfLayerMask))
//        {
//            hitPos = hit.point;
//            Vector3 dir = Camera.main.transform.forward; dir.y = 0; dir.Normalize();
//            hitRot = Quaternion.LookRotation(dir, Vector3.up);
//            return true;
//        }
//        return false;
//    }

//    void SpawnPreview(Vector3 pos, Quaternion rot)
//    {
//        if (runtimeModelPrefab != null)
//        {
//            previewObject = runtimeModelPrefab;
//            previewObject.transform.position = pos;
//            previewObject.transform.rotation = rot;
//            previewObject.transform.localScale = Vector3.one * 0.01f;
//            previewObject.SetActive(true);
//        }
//        else previewObject = Instantiate(objectPrefabs[selectedIndex], pos, rot);
//        isPlacingMode = false; isAdjustingMode = true; confirmPanel.SetActive(true);
//    }

//    void HandleAdjustment(IReadOnlyList<Touch> activeTouches)
//    {
//        if (activeTouches.Count == 1)
//        {
//            var touch = activeTouches[0];
//            if (touch.phase == UnityEngine.InputSystem.TouchPhase.Moved)
//            {
//                if (TryRaycastShelf(touch.screenPosition, out Vector3 sp, out _))
//                    previewObject.transform.position = ClampToRoom(sp);
//                else if (arRaycastManager.Raycast(touch.screenPosition, hits, TrackableType.PlaneWithinPolygon))
//                    previewObject.transform.position = ClampToRoom(hits[0].pose.position);
//            }
//        }
//        else if (activeTouches.Count == 2)
//        {
//            var t1 = activeTouches[0]; var t2 = activeTouches[1];
//            float dist = Vector2.Distance(t1.screenPosition, t2.screenPosition);
//            float angle = Mathf.Atan2(t2.screenPosition.y - t1.screenPosition.y, t2.screenPosition.x - t1.screenPosition.x) * Mathf.Rad2Deg;
//            if (t1.phase == UnityEngine.InputSystem.TouchPhase.Began || t2.phase == UnityEngine.InputSystem.TouchPhase.Began)
//            { lastPinchDistance = dist; lastTwoFingerAngle = angle; }
//            else
//            {
//                float scale = Mathf.Clamp(previewObject.transform.localScale.x * (dist / lastPinchDistance), 0.001f, 2f);
//                previewObject.transform.localScale = Vector3.one * scale;
//                previewObject.transform.Rotate(0f, -(angle - lastTwoFingerAngle), 0f, Space.World);
//                lastPinchDistance = dist; lastTwoFingerAngle = angle;
//            }
//        }
//    }

//    Vector3 ClampToRoom(Vector3 pos)
//    {
//        if (portalRoom == null) return pos;
//        Bounds b = GetRoomBounds();
//        pos.x = Mathf.Clamp(pos.x, b.min.x, b.max.x);
//        pos.z = Mathf.Clamp(pos.z, b.min.z, b.max.z);
//        return pos;
//    }

//    Bounds GetRoomBounds()
//    {
//        Renderer[] r = portalRoom.GetComponentsInChildren<Renderer>();
//        if (r.Length == 0) return new Bounds(portalRoom.transform.position, Vector3.one * 3f);
//        Bounds b = r[0].bounds; foreach (var rr in r) b.Encapsulate(rr.bounds); return b;
//    }

//    public void OnConfirmPressed()
//    {
//        if (previewObject == null) return;
//        EnsureCollider(previewObject);
//        if (portalRoom != null) previewObject.transform.SetParent(portalRoom.transform);

//        string fname = !string.IsNullOrEmpty(runtimeModelFileName) ? runtimeModelFileName
//            : (selectedIndex >= 0 ? objectNames[selectedIndex] : "unknown");

//        AttachMetaData(previewObject, fname);
//        SpawnIndicator(previewObject);
//        placedObjects.Add(previewObject);
//        objectFileNames[previewObject] = fname;
//        SaveObjectToRoom(previewObject, fname);

//        // Show settings after placing so owner can set name/price
//        if (!isVisitorMode)
//        {
//            var meta = previewObject.GetComponent<ObjectMetaData>();
//            GameObject objRef = previewObject;
//            if (meta != null)
//                ownerSettings?.Show(meta, () => SaveMetaToRoom(objRef));
//        }

//        previewObject = null; runtimeModelPrefab = null; runtimeModelFileName = "";
//        selectedIndex = -1; isAdjustingMode = false;
//        confirmPanel.SetActive(false); bottomBar.SetActive(true);
//    }

//    public void OnCancelPressed()
//    {
//        if (previewObject != null) { Destroy(previewObject); previewObject = null; }
//        runtimeModelPrefab = null; runtimeModelFileName = "";
//        selectedIndex = -1; isAdjustingMode = false; isPlacingMode = false;
//        confirmPanel.SetActive(false); bottomBar.SetActive(true);
//    }

//    void SaveObjectToRoom(GameObject obj, string fileName)
//    {
//        if (RoomManager.Instance == null || !RoomManager.IsOwner) return;
//        var meta = obj.GetComponent<ObjectMetaData>();
//        RoomManager.Instance.AddObjectToRoom(new PlacedObjectData
//        {
//            instanceId = meta?.instanceId ?? "",
//            fileName = fileName,
//            posX = obj.transform.localPosition.x,
//            posY = obj.transform.localPosition.y,
//            posZ = obj.transform.localPosition.z,
//            rotX = obj.transform.localRotation.x,
//            rotY = obj.transform.localRotation.y,
//            rotZ = obj.transform.localRotation.z,
//            rotW = obj.transform.localRotation.w,
//            scaleX = obj.transform.localScale.x,
//            scaleY = obj.transform.localScale.y,
//            scaleZ = obj.transform.localScale.z,
//            objectName = meta?.objectName ?? "My Object",
//            description = meta?.description ?? "",
//            objectType = (int)(meta?.objectType ?? ObjectMetaData.ObjectType.ViewOnly),
//            price = meta?.price ?? 0f,
//            currency = meta?.currency ?? "MYR"
//        });
//    }

//    void SaveMetaToRoom(GameObject obj)
//    {
//        if (RoomManager.Instance == null || !RoomManager.IsOwner) return;
//        var meta = obj.GetComponent<ObjectMetaData>();
//        if (meta != null) RoomManager.Instance.UpdateObjectMeta(meta);
//    }

//    void RemoveObjectFromRoom(GameObject obj)
//    {
//        if (RoomManager.Instance == null || !RoomManager.IsOwner) return;
//        var meta = obj.GetComponent<ObjectMetaData>();
//        if (meta != null) RoomManager.Instance.RemoveObjectFromRoom(meta.instanceId);
//    }

//    void EnsureCollider(GameObject obj)
//    {
//        if (obj.GetComponentInChildren<Collider>() != null) return;
//        Renderer[] rends = obj.GetComponentsInChildren<Renderer>();
//        if (rends.Length == 0) { obj.AddComponent<BoxCollider>().size = Vector3.one * 0.3f; return; }
//        Bounds b = rends[0].bounds; foreach (var r in rends) b.Encapsulate(r.bounds);
//        BoxCollider col = obj.AddComponent<BoxCollider>();
//        col.center = obj.transform.InverseTransformPoint(b.center);
//        Vector3 s = obj.transform.InverseTransformVector(b.size);
//        col.size = new Vector3(Mathf.Abs(s.x), Mathf.Abs(s.y), Mathf.Abs(s.z));
//    }

//    void TrySelectPlacedObject(Vector2 screenPos)
//    {
//        if (!RoomInsideDetector.IsInsideRoom) return;
//        Ray ray = Camera.main.ScreenPointToRay(screenPos);
//        RaycastHit[] allHits = Physics.RaycastAll(ray, 10f);
//        System.Array.Sort(allHits, (a, b) => a.distance.CompareTo(b.distance));

//        foreach (var hit in allHits)
//        {
//            GameObject placed = FindPlacedObjectInParents(hit.collider.gameObject);
//            if (placed != null)
//            {
//                if (currentlySelectedObject == placed && isPopupOpen) { ClosePopup(); currentlySelectedObject = null; return; }
//                if (isPopupOpen) ClosePopup();
//                if (!isVisitorMode)
//                    OpenPopup(placed);
//                else
//                {
//                    var meta = placed.GetComponent<ObjectMetaData>();
//                    if (meta != null) visitorPopup?.Show(placed, meta);
//                }
//                return;
//            }
//        }
//        if (isPopupOpen) { ClosePopup(); currentlySelectedObject = null; }
//    }

//    GameObject FindPlacedObjectInParents(GameObject obj)
//    {
//        Transform t = obj.transform;
//        while (t != null) { if (placedObjects.Contains(t.gameObject)) return t.gameObject; t = t.parent; }
//        return null;
//    }

//    public void BeginEditExistingObject(GameObject obj)
//    {
//        if (obj == null) return;
//        if (portalRoom != null) obj.transform.SetParent(null);
//        RemoveObjectFromRoom(obj);
//        placedObjects.Remove(obj);
//        previewObject = obj; isAdjustingMode = true; isPopupOpen = false;
//        confirmPanel.SetActive(true); currentlySelectedObject = null;
//        editPopupPanel.SetActive(false); bottomBar.SetActive(false);
//        if (objectFileNames.ContainsKey(obj)) runtimeModelFileName = objectFileNames[obj];
//    }

//    public void DeleteObject(GameObject obj)
//    {
//        if (obj == null) return;
//        RemoveObjectFromRoom(obj);
//        objectFileNames.Remove(obj);
//        placedObjects.Remove(obj);
//        currentlySelectedObject = null; isPopupOpen = false;
//        editPopupPanel.SetActive(false);
//        Destroy(obj);
//    }
//}


using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using System.Collections.Generic;
using UnityEngine.InputSystem.EnhancedTouch;
using TMPro;
using UnityEngine.UI;
using Touch = UnityEngine.InputSystem.EnhancedTouch.Touch;

public class ObjectPlacementController : MonoBehaviour
{
    [Header("AR")]
    [SerializeField] private ARRaycastManager arRaycastManager;

    [Header("Prefab Objects")]
    [SerializeField] private GameObject[] objectPrefabs;
    [SerializeField] private string[] objectNames;

    [Header("UI")]
    [SerializeField] private GameObject bottomBar;
    [SerializeField] private GameObject objectListPanel;
    [SerializeField] private Transform listContent;
    [SerializeField] private GameObject listItemPrefab;
    [SerializeField] private GameObject confirmPanel;

    [Header("Owner Edit/Delete Popup")]
    [SerializeField] private GameObject editPopupPanel;
    [SerializeField] private Button editButton;
    [SerializeField] private Button deleteButton;
    [SerializeField] private Button settingsButton;

    [Header("Room Bounds")]
    [SerializeField] private GameObject portalRoom;

    [Header("Shelf Snapping")]
    [SerializeField] private LayerMask shelfLayerMask;
    [SerializeField] private float shelfSnapRayDistance = 5f;

    [Header("Object Features")]
    [SerializeField] private GameObject indicatorPrefab;
    [SerializeField] private VisitorObjectPopup visitorPopup;
    [SerializeField] private OwnerObjectSettings ownerSettings;

    private List<ARRaycastHit> hits = new List<ARRaycastHit>();
    private int selectedIndex = -1;
    private bool isPlacingMode = false;
    private bool isAdjustingMode = false;
    private bool isVisitorMode = false;

    private GameObject runtimeModelPrefab = null;
    private string runtimeModelFileName = "";
    private GameObject previewObject = null;

    private float lastPinchDistance;
    private float lastTwoFingerAngle;

    private List<GameObject> placedObjects = new List<GameObject>();
    private Dictionary<GameObject, string> objectFileNames = new Dictionary<GameObject, string>();
    private GameObject currentlySelectedObject = null;
    private List<GameObject> shelfObjects = new List<GameObject>();
    private bool isPopupOpen = false;

    void OnEnable() => EnhancedTouchSupport.Enable();
    void OnDisable() => EnhancedTouchSupport.Disable();

    void Start()
    {
        bottomBar.SetActive(false);
        objectListPanel.SetActive(false);
        confirmPanel.SetActive(false);
        editPopupPanel.SetActive(false);
        PopulateList();

        if (editButton != null) { editButton.onClick.RemoveAllListeners(); editButton.onClick.AddListener(OnEditPopupPressed); }
        if (deleteButton != null) { deleteButton.onClick.RemoveAllListeners(); deleteButton.onClick.AddListener(OnDeletePopupPressed); }
        if (settingsButton != null) { settingsButton.onClick.RemoveAllListeners(); settingsButton.onClick.AddListener(OnSettingsPopupPressed); }
    }

    public void SetVisitorMode(bool visitor)
    {
        isVisitorMode = visitor;
        if (visitor) { bottomBar.SetActive(false); editPopupPanel.SetActive(false); }
    }

    public void RegisterRestoredObject(GameObject obj, string fileName, PlacedObjectData data = null)
    {
        EnsureCollider(obj);
        AttachMetaData(obj, fileName, data);
        SpawnIndicator(obj);
        placedObjects.Add(obj);
        objectFileNames[obj] = fileName;
        Debug.Log($"[OBJECT] Registered: {fileName} | name={data?.objectName} | type={data?.objectType}");
    }

    void AttachMetaData(GameObject obj, string fileName, PlacedObjectData data = null)
    {
        var meta = obj.GetComponent<ObjectMetaData>();
        if (meta == null) meta = obj.AddComponent<ObjectMetaData>();

        meta.Init(RoomManager.Instance?.CurrentRoom?.roomId ?? "");

        if (data != null)
        {
            // Restore saved instanceId so updates work correctly
            if (!string.IsNullOrEmpty(data.instanceId))
                meta.instanceId = data.instanceId;

            meta.objectName = data.objectName;
            meta.description = data.description;
            meta.objectType = (ObjectMetaData.ObjectType)data.objectType;
            meta.price = data.price;
            meta.currency = data.currency;
        }
        else
        {
            meta.objectName = System.IO.Path.GetFileNameWithoutExtension(fileName);
        }
    }

    void SpawnIndicator(GameObject obj)
    {
        if (indicatorPrefab == null) return;
        var meta = obj.GetComponent<ObjectMetaData>();
        if (meta == null) return;
        GameObject indicator = Instantiate(indicatorPrefab);
        var indUI = indicator.GetComponent<ObjectIndicatorUI>();
        if (indUI != null) indUI.SetTarget(obj.transform);
        meta.SetIndicator(indicator);
    }

    // ── Popup handlers ────────────────────────────────────────────────────

    void OnEditPopupPressed()
    {
        if (currentlySelectedObject == null) return;
        ClosePopup();
        BeginEditExistingObject(currentlySelectedObject);
    }

    void OnDeletePopupPressed()
    {
        if (currentlySelectedObject == null) return;
        ClosePopup();
        DeleteObject(currentlySelectedObject);
    }

    void OnSettingsPopupPressed()
    {
        if (currentlySelectedObject == null) return;

        // FIX: close edit popup BEFORE opening settings
        // prevents both being open at same time
        ClosePopup();

        var meta = currentlySelectedObject.GetComponent<ObjectMetaData>();
        if (meta != null)
        {
            GameObject objRef = currentlySelectedObject;
            ownerSettings?.Show(meta, () => SaveMetaToRoom(objRef));
        }
    }

    void OpenPopup(GameObject obj)
    {
        // FIX: don't open if settings or visitor popup already open
        if (ownerSettings != null && ownerSettings.IsOpen) return;

        currentlySelectedObject = obj;
        editPopupPanel.SetActive(true);
        isPopupOpen = true;
    }

    void ClosePopup()
    {
        editPopupPanel.SetActive(false);
        isPopupOpen = false;
    }

    public void SetPopupOpen(bool open) => isPopupOpen = open;
    public void ShowBottomBar() => bottomBar.SetActive(true);
    public void HideBottomBar() => bottomBar.SetActive(false);
    public void SetPortalRoom(GameObject room) { portalRoom = room; }
    public void RefreshShelfSurfaces(List<GameObject> shelves) { shelfObjects = new List<GameObject>(shelves); }

    public void OnAddObjectButtonPressed()
    {
        if (isVisitorMode || !RoomInsideDetector.IsInsideRoom) return;
        objectListPanel.SetActive(true);
        bottomBar.SetActive(false);
    }

    void PopulateList()
    {
        foreach (Transform child in listContent) Destroy(child.gameObject);
        for (int i = 0; i < objectPrefabs.Length; i++)
        {
            int index = i;
            GameObject item = Instantiate(listItemPrefab, listContent);
            item.GetComponentInChildren<TMP_Text>().text = objectNames[i];
            item.GetComponent<Button>().onClick.AddListener(() => OnObjectSelected(index));
        }
    }

    void OnObjectSelected(int index) { selectedIndex = index; isPlacingMode = true; objectListPanel.SetActive(false); }

    public void SetRuntimeModel(GameObject model, string fileName = "")
    {
        runtimeModelPrefab = model;
        runtimeModelFileName = fileName;
        runtimeModelPrefab.SetActive(false);
        isPlacingMode = true;
        bottomBar.SetActive(false);
    }

    void Update()
    {
        var activeTouches = Touch.activeTouches;

        if (isPlacingMode)
        {
            if (activeTouches.Count == 0) return;
            var touch = activeTouches[0];
            if (touch.phase != UnityEngine.InputSystem.TouchPhase.Began) return;
            TryPlaceObject(touch.screenPosition);
            return;
        }

        if (isAdjustingMode && previewObject != null) { HandleAdjustment(activeTouches); return; }

        // FIX: also block tap if settings panel is open
        if (!isPlacingMode && !isAdjustingMode && !isPopupOpen &&
            !(ownerSettings != null && ownerSettings.IsOpen))
        {
            if (activeTouches.Count == 1)
            {
                var touch = activeTouches[0];
                if (touch.phase == UnityEngine.InputSystem.TouchPhase.Began)
                    TrySelectPlacedObject(touch.screenPosition);
            }
        }
    }

    void TryPlaceObject(Vector2 screenPos)
    {
        Vector3 spawnPos; Quaternion spawnRot;
        if (TryRaycastShelf(screenPos, out Vector3 sp, out Quaternion sr)) { spawnPos = sp; spawnRot = sr; }
        else if (arRaycastManager.Raycast(screenPos, hits, TrackableType.PlaneWithinPolygon)) { spawnPos = hits[0].pose.position; spawnRot = hits[0].pose.rotation; }
        else
        {
            Vector3 fwd = Camera.main.transform.forward; fwd.y = 0; fwd.Normalize();
            spawnPos = Camera.main.transform.position + fwd * 1.5f; spawnPos.y = 0f;
            spawnRot = Quaternion.LookRotation(fwd, Vector3.up);
        }
        SpawnPreview(spawnPos, spawnRot);
    }

    bool TryRaycastShelf(Vector2 screenPos, out Vector3 hitPos, out Quaternion hitRot)
    {
        hitPos = Vector3.zero; hitRot = Quaternion.identity;
        if (shelfObjects.Count == 0) return false;
        Ray ray = Camera.main.ScreenPointToRay(screenPos);
        if (Physics.Raycast(ray, out RaycastHit hit, shelfSnapRayDistance, shelfLayerMask))
        {
            hitPos = hit.point;
            Vector3 dir = Camera.main.transform.forward; dir.y = 0; dir.Normalize();
            hitRot = Quaternion.LookRotation(dir, Vector3.up);
            return true;
        }
        return false;
    }

    void SpawnPreview(Vector3 pos, Quaternion rot)
    {
        if (runtimeModelPrefab != null)
        {
            previewObject = runtimeModelPrefab;
            previewObject.transform.position = pos;
            previewObject.transform.rotation = rot;
            previewObject.transform.localScale = Vector3.one * 0.01f;
            previewObject.SetActive(true);
        }
        else previewObject = Instantiate(objectPrefabs[selectedIndex], pos, rot);
        isPlacingMode = false; isAdjustingMode = true; confirmPanel.SetActive(true);
    }

    void HandleAdjustment(IReadOnlyList<Touch> activeTouches)
    {
        if (activeTouches.Count == 1)
        {
            var touch = activeTouches[0];
            if (touch.phase == UnityEngine.InputSystem.TouchPhase.Moved)
            {
                if (TryRaycastShelf(touch.screenPosition, out Vector3 sp, out _))
                    previewObject.transform.position = ClampToRoom(sp);
                else if (arRaycastManager.Raycast(touch.screenPosition, hits, TrackableType.PlaneWithinPolygon))
                    previewObject.transform.position = ClampToRoom(hits[0].pose.position);
            }
        }
        else if (activeTouches.Count == 2)
        {
            var t1 = activeTouches[0]; var t2 = activeTouches[1];
            float dist = Vector2.Distance(t1.screenPosition, t2.screenPosition);
            float angle = Mathf.Atan2(t2.screenPosition.y - t1.screenPosition.y, t2.screenPosition.x - t1.screenPosition.x) * Mathf.Rad2Deg;
            if (t1.phase == UnityEngine.InputSystem.TouchPhase.Began || t2.phase == UnityEngine.InputSystem.TouchPhase.Began)
            { lastPinchDistance = dist; lastTwoFingerAngle = angle; }
            else
            {
                float scale = Mathf.Clamp(previewObject.transform.localScale.x * (dist / lastPinchDistance), 0.001f, 2f);
                previewObject.transform.localScale = Vector3.one * scale;
                previewObject.transform.Rotate(0f, -(angle - lastTwoFingerAngle), 0f, Space.World);
                lastPinchDistance = dist; lastTwoFingerAngle = angle;
            }
        }
    }

    Vector3 ClampToRoom(Vector3 pos)
    {
        if (portalRoom == null) return pos;
        Bounds b = GetRoomBounds();
        pos.x = Mathf.Clamp(pos.x, b.min.x, b.max.x);
        pos.z = Mathf.Clamp(pos.z, b.min.z, b.max.z);
        return pos;
    }

    Bounds GetRoomBounds()
    {
        Renderer[] r = portalRoom.GetComponentsInChildren<Renderer>();
        if (r.Length == 0) return new Bounds(portalRoom.transform.position, Vector3.one * 3f);
        Bounds b = r[0].bounds; foreach (var rr in r) b.Encapsulate(rr.bounds); return b;
    }

    public void OnConfirmPressed()
    {
        if (previewObject == null) return;
        EnsureCollider(previewObject);
        if (portalRoom != null) previewObject.transform.SetParent(portalRoom.transform);

        string fname = !string.IsNullOrEmpty(runtimeModelFileName) ? runtimeModelFileName
            : (selectedIndex >= 0 ? objectNames[selectedIndex] : "unknown");

        AttachMetaData(previewObject, fname);
        SpawnIndicator(previewObject);
        placedObjects.Add(previewObject);
        objectFileNames[previewObject] = fname;
        SaveObjectToRoom(previewObject, fname);

        // Show settings after placing so owner can set name/price
        if (!isVisitorMode)
        {
            var meta = previewObject.GetComponent<ObjectMetaData>();
            GameObject objRef = previewObject;
            if (meta != null)
                ownerSettings?.Show(meta, () => SaveMetaToRoom(objRef));
        }

        previewObject = null; runtimeModelPrefab = null; runtimeModelFileName = "";
        selectedIndex = -1; isAdjustingMode = false;
        confirmPanel.SetActive(false); bottomBar.SetActive(true);
    }

    public void OnCancelPressed()
    {
        if (previewObject != null) { Destroy(previewObject); previewObject = null; }
        runtimeModelPrefab = null; runtimeModelFileName = "";
        selectedIndex = -1; isAdjustingMode = false; isPlacingMode = false;
        confirmPanel.SetActive(false); bottomBar.SetActive(true);
    }

    void SaveObjectToRoom(GameObject obj, string fileName)
    {
        if (RoomManager.Instance == null || !RoomManager.IsOwner) return;
        var meta = obj.GetComponent<ObjectMetaData>();
        RoomManager.Instance.AddObjectToRoom(new PlacedObjectData
        {
            instanceId = meta?.instanceId ?? "",
            fileName = fileName,
            posX = obj.transform.localPosition.x,
            posY = obj.transform.localPosition.y,
            posZ = obj.transform.localPosition.z,
            rotX = obj.transform.localRotation.x,
            rotY = obj.transform.localRotation.y,
            rotZ = obj.transform.localRotation.z,
            rotW = obj.transform.localRotation.w,
            scaleX = obj.transform.localScale.x,
            scaleY = obj.transform.localScale.y,
            scaleZ = obj.transform.localScale.z,
            objectName = meta?.objectName ?? "My Object",
            description = meta?.description ?? "",
            objectType = (int)(meta?.objectType ?? ObjectMetaData.ObjectType.ViewOnly),
            price = meta?.price ?? 0f,
            currency = meta?.currency ?? "MYR"
        });
    }

    void SaveMetaToRoom(GameObject obj)
    {
        if (RoomManager.Instance == null || !RoomManager.IsOwner) return;
        var meta = obj.GetComponent<ObjectMetaData>();
        if (meta != null) RoomManager.Instance.UpdateObjectMeta(meta);
    }

    void RemoveObjectFromRoom(GameObject obj)
    {
        if (RoomManager.Instance == null || !RoomManager.IsOwner) return;
        var meta = obj.GetComponent<ObjectMetaData>();
        if (meta != null) RoomManager.Instance.RemoveObjectFromRoom(meta.instanceId);
    }

    void EnsureCollider(GameObject obj)
    {
        if (obj.GetComponentInChildren<Collider>() != null) return;
        Renderer[] rends = obj.GetComponentsInChildren<Renderer>();
        if (rends.Length == 0) { obj.AddComponent<BoxCollider>().size = Vector3.one * 0.3f; return; }
        Bounds b = rends[0].bounds; foreach (var r in rends) b.Encapsulate(r.bounds);
        BoxCollider col = obj.AddComponent<BoxCollider>();
        col.center = obj.transform.InverseTransformPoint(b.center);
        Vector3 s = obj.transform.InverseTransformVector(b.size);
        col.size = new Vector3(Mathf.Abs(s.x), Mathf.Abs(s.y), Mathf.Abs(s.z));
    }

    void TrySelectPlacedObject(Vector2 screenPos)
    {
        if (!RoomInsideDetector.IsInsideRoom) return;
        Ray ray = Camera.main.ScreenPointToRay(screenPos);
        RaycastHit[] allHits = Physics.RaycastAll(ray, 10f);
        System.Array.Sort(allHits, (a, b) => a.distance.CompareTo(b.distance));

        foreach (var hit in allHits)
        {
            GameObject placed = FindPlacedObjectInParents(hit.collider.gameObject);
            if (placed != null)
            {
                if (currentlySelectedObject == placed && isPopupOpen) { ClosePopup(); currentlySelectedObject = null; return; }
                if (isPopupOpen) ClosePopup();
                if (!isVisitorMode)
                    OpenPopup(placed);
                else
                {
                    var meta = placed.GetComponent<ObjectMetaData>();
                    if (meta != null) visitorPopup?.Show(placed, meta);
                }
                return;
            }
        }
        if (isPopupOpen) { ClosePopup(); currentlySelectedObject = null; }
    }

    GameObject FindPlacedObjectInParents(GameObject obj)
    {
        Transform t = obj.transform;
        while (t != null) { if (placedObjects.Contains(t.gameObject)) return t.gameObject; t = t.parent; }
        return null;
    }

    public void BeginEditExistingObject(GameObject obj)
    {
        if (obj == null) return;
        if (portalRoom != null) obj.transform.SetParent(null);
        RemoveObjectFromRoom(obj);
        placedObjects.Remove(obj);
        previewObject = obj; isAdjustingMode = true; isPopupOpen = false;
        confirmPanel.SetActive(true); currentlySelectedObject = null;
        editPopupPanel.SetActive(false); bottomBar.SetActive(false);
        if (objectFileNames.ContainsKey(obj)) runtimeModelFileName = objectFileNames[obj];
    }

    public void DeleteObject(GameObject obj)
    {
        if (obj == null) return;
        RemoveObjectFromRoom(obj);
        objectFileNames.Remove(obj);
        placedObjects.Remove(obj);
        currentlySelectedObject = null; isPopupOpen = false;
        editPopupPanel.SetActive(false);
        Destroy(obj);
    }
}

