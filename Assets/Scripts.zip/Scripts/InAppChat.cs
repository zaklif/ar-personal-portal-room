﻿//using System.Collections;
//using System.Collections.Generic;
//using TMPro;
//using UnityEngine;
//using UnityEngine.UI;

///// <summary>
///// Simple in-app chat screen.
///// No backend yet — messages stored locally.
///// When Firebase is added, replace the local storage with Firestore.
/////
///// SETUP — Create this UI in Canvas:
///// ChatPanel (Panel, set inactive, full screen)
///// ├── Header
///// │   ├── ChatTitleText (TMP_Text)      "Chat with Room Owner"
///// │   ├── ItemInfoText (TMP_Text)       "Re: Chair - RM 99.00"
///// │   └── CloseButton (Button)          "✕"
///// ├── MessageScrollView (Scroll View)
///// │   └── Viewport → Content           (Vertical Layout Group)
///// │       └── [messages spawned here]
///// ├── InputSection
///// │   ├── MessageInputField (TMP_InputField)
///// │   └── SendButton (Button)           "Send"
///// └── NoteText (TMP_Text)
/////     "Note: Chat is local only. Add owner's contact below to reach them."
/////
///// MessageBubblePrefab:
///// ├── BubbleBackground (Image)
///// └── MessageText (TMP_Text)
///// </summary>
//public class InAppChat : MonoBehaviour
//{
//    [Header("Panel")]
//    [SerializeField] private GameObject chatPanel;

//    [Header("Header")]
//    [SerializeField] private TMP_Text chatTitleText;
//    [SerializeField] private TMP_Text itemInfoText;
//    [SerializeField] private Button closeButton;

//    [Header("Messages")]
//    [SerializeField] private Transform messageContainer;  // Content inside ScrollView
//    [SerializeField] private GameObject messageBubblePrefab;
//    [SerializeField] private ScrollRect scrollRect;

//    [Header("Input")]
//    [SerializeField] private TMP_InputField messageInputField;
//    [SerializeField] private Button sendButton;

//    [Header("Note")]
//    [SerializeField] private TMP_Text noteText;

//    [Header("Message Prefabs")]
//    [SerializeField] private GameObject leftBubblePrefab;
//    [SerializeField] private GameObject rightBubblePrefab;

//    // Chat state
//    private string currentRoomId;
//    private string currentItemName;
//    private List<ChatMessage> messages = new List<ChatMessage>();

//    // Save key for local storage
//    private string ChatSaveKey => "Chat_" + currentRoomId;

//    void Start()
//    {
//        chatPanel.SetActive(false);
//        closeButton.onClick.AddListener(Hide);
//        sendButton.onClick.AddListener(OnSendPressed);

//        // Send on Enter key
//        messageInputField.onSubmit.AddListener((_) => OnSendPressed());
//    }

//    // ── Open chat ─────────────────────────────────────────────────────────

//    public void OpenChat(string ownerRoomId, string itemName, float price, string currency)
//    {
//        currentRoomId = ownerRoomId;
//        currentItemName = itemName;

//        chatTitleText.text = "Chat with Room Owner";
//        itemInfoText.text = $"Re: {itemName} — {currency} {price:F2}";
//        noteText.text = "💬 Messages are saved locally on your device.\nTo connect with owner, share your Room ID.";

//        // Load existing messages for this room
//        LoadMessages();

//        // Add auto first message if no messages yet
//        if (messages.Count == 0)
//        {
//            AddMessage($"Hi! I'm interested in your '{itemName}' listed at {currency} {price:F2}. Is it still available?", isOwn: true, autoSend: false);
//        }

//        chatPanel.SetActive(true);
//        ScrollToBottom();

//        Debug.Log($"[CHAT] Opened for room: {ownerRoomId} item: {itemName}");
//    }

//    public void Hide()
//    {
//        chatPanel.SetActive(false);
//        SaveMessages();
//    }

//    // ── Send message ──────────────────────────────────────────────────────

//    void OnSendPressed()
//    {
//        string text = messageInputField.text.Trim();
//        if (string.IsNullOrEmpty(text)) return;

//        AddMessage(text, isOwn: true, autoSend: true);
//        messageInputField.text = "";
//        messageInputField.ActivateInputField();

//        // TODO: When Firebase added — send to Firestore here
//        // FirebaseFirestore.DefaultInstance
//        //   .Collection("chats").Document(currentRoomId)
//        //   .Collection("messages").AddAsync(new { text, senderId, timestamp });
//    }

//    void AddMessage(string text, bool isOwn, bool autoSend)
//    {
//        var msg = new ChatMessage { text = text, isOwn = isOwn, timestamp = System.DateTime.Now.ToString("HH:mm") };
//        messages.Add(msg);
//        SpawnBubble(msg);
//        if (autoSend) SaveMessages();
//        ScrollToBottom();
//    }

//    void SpawnBubble(ChatMessage msg)
//    {
//        GameObject bubble = Instantiate(messageBubblePrefab, messageContainer);

//        var msgText = bubble.GetComponentInChildren<TMP_Text>();
//        if (msgText != null)
//            msgText.text = $"{msg.text}\n<size=10><color=#888888>{msg.timestamp}</color></size>";

//        var bg = bubble.GetComponent<Image>();
//        if (bg != null)
//            bg.color = msg.isOwn
//                ? new Color(0.2f, 0.6f, 1f, 0.9f)    // blue for own messages
//                : new Color(0.3f, 0.3f, 0.3f, 0.9f);  // grey for received

//        // Align own messages to right, received to left
//        var rt = bubble.GetComponent<RectTransform>();
//        if (rt != null)
//        {
//            rt.anchorMin = msg.isOwn ? new Vector2(0.3f, 0) : new Vector2(0, 0);
//            rt.anchorMax = msg.isOwn ? new Vector2(1f, 0) : new Vector2(0.7f, 0);
//        }
//    }

//    void ScrollToBottom()
//    {
//        // Wait one frame for layout to update then scroll
//        StartCoroutine(ScrollCoroutine());
//    }

//    IEnumerator ScrollCoroutine()
//    {
//        yield return null;
//        yield return new WaitForEndOfFrame();

//        if (scrollRect == null)
//        {
//            Debug.LogWarning("[CHAT] ScrollRect is NULL");
//            yield break;
//        }

//        if (scrollRect.content == null)
//        {
//            Debug.LogWarning("[CHAT] ScrollRect content is NULL");
//            yield break;
//        }

//        Canvas.ForceUpdateCanvases();

//        LayoutRebuilder.ForceRebuildLayoutImmediate(scrollRect.content);

//        scrollRect.verticalNormalizedPosition = 0f;
//    }

//    // ── Local save/load ───────────────────────────────────────────────────

//    void SaveMessages()
//    {
//        var wrapper = new ChatSaveWrapper { messages = messages };
//        string json = JsonUtility.ToJson(wrapper);
//        PlayerPrefs.SetString(ChatSaveKey, json);
//        PlayerPrefs.Save();
//    }

//    void LoadMessages()
//    {
//        // Clear existing bubbles
//        foreach (Transform child in messageContainer)
//            Destroy(child.gameObject);
//        messages.Clear();

//        string json = PlayerPrefs.GetString(ChatSaveKey, "");
//        if (string.IsNullOrEmpty(json)) return;

//        var wrapper = JsonUtility.FromJson<ChatSaveWrapper>(json);
//        if (wrapper?.messages == null) return;

//        foreach (var msg in wrapper.messages)
//        {
//            messages.Add(msg);
//            SpawnBubble(msg);
//        }
//    }

//    [System.Serializable]
//    class ChatMessage
//    {
//        public string text;
//        public bool isOwn;
//        public string timestamp;
//    }

//    [System.Serializable]
//    class ChatSaveWrapper
//    {
//        public List<ChatMessage> messages;
//    }
//}

using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Simple in-app chat screen.
/// No backend yet — messages stored locally.
/// When Firebase is added, replace the local storage with Firestore.
///
/// SETUP — Create this UI in Canvas:
/// ChatPanel (Panel, set inactive, full screen)
/// ├── Header
/// │   ├── ChatTitleText (TMP_Text)      "Chat with Room Owner"
/// │   ├── ItemInfoText (TMP_Text)       "Re: Chair - RM 99.00"
/// │   └── CloseButton (Button)          "✕"
/// ├── MessageScrollView (Scroll View)
/// │   └── Viewport → Content           (Vertical Layout Group)
/// │       └── [messages spawned here]
/// ├── InputSection
/// │   ├── MessageInputField (TMP_InputField)
/// │   └── SendButton (Button)           "Send"
/// └── NoteText (TMP_Text)
///     "Note: Chat is local only. Add owner's contact below to reach them."
///
/// MessageBubblePrefab:
/// ├── BubbleBackground (Image)
/// └── MessageText (TMP_Text)
/// </summary>
public class InAppChat : MonoBehaviour
{
    [Header("Panel")]
    [SerializeField] private GameObject chatPanel;

    [Header("Header")]
    [SerializeField] private TMP_Text chatTitleText;
    [SerializeField] private TMP_Text itemInfoText;
    [SerializeField] private Button closeButton;

    [Header("Messages")]
    [SerializeField] private Transform messageContainer;  // Content inside ScrollView
    [SerializeField] private GameObject messageBubblePrefab;
    [SerializeField] private ScrollRect scrollRect;

    [Header("Input")]
    [SerializeField] private TMP_InputField messageInputField;
    [SerializeField] private Button sendButton;

    [Header("Note")]
    [SerializeField] private TMP_Text noteText;

    [Header("Message Prefabs")]
    [SerializeField] private GameObject leftBubblePrefab;
    [SerializeField] private GameObject rightBubblePrefab;

    // Chat state
    private string currentRoomId;
    private string currentItemName;
    private List<ChatMessage> messages = new List<ChatMessage>();

    // Save key for local storage
    private string ChatSaveKey => "Chat_" + currentRoomId;

    void Start()
    {
        chatPanel.SetActive(false);
        closeButton.onClick.AddListener(Hide);
        sendButton.onClick.AddListener(OnSendPressed);

        // Send on Enter key
        messageInputField.onSubmit.AddListener((_) => OnSendPressed());
    }

    // ── Open chat ─────────────────────────────────────────────────────────

    public void OpenChat(string ownerRoomId, string itemName, float price, string currency)
    {
        currentRoomId = ownerRoomId;
        currentItemName = itemName;

        chatTitleText.text = "Chat with Room Owner";
        itemInfoText.text = $"Re: {itemName} — {currency} {price:F2}";
        noteText.text = "💬 Messages are saved locally on your device.\nTo connect with owner, share your Room ID.";

        // Load existing messages for this room
        LoadMessages();

        // Add auto first message if no messages yet
        if (messages.Count == 0)
        {
            AddMessage($"Hi! I'm interested in your '{itemName}' listed at {currency} {price:F2}. Is it still available?", isOwn: true, autoSend: false);
        }

        chatPanel.SetActive(true);
        ScrollToBottom();

        Debug.Log($"[CHAT] Opened for room: {ownerRoomId} item: {itemName}");
    }

    public void Hide()
    {
        chatPanel.SetActive(false);
        SaveMessages();
    }

    // ── Send message ──────────────────────────────────────────────────────

    void OnSendPressed()
    {
        string text = messageInputField.text.Trim();
        if (string.IsNullOrEmpty(text)) return;

        AddMessage(text, isOwn: true, autoSend: true);

        messageInputField.text = "";
        messageInputField.ActivateInputField();

        StartCoroutine(FakeOwnerReply());
    }

    void AddMessage(string text, bool isOwn, bool autoSend)
    {
        var msg = new ChatMessage { text = text, isOwn = isOwn, timestamp = System.DateTime.Now.ToString("HH:mm") };
        messages.Add(msg);
        SpawnBubble(msg);
        if (autoSend) SaveMessages();
        ScrollToBottom();
    }
    IEnumerator FakeOwnerReply()
    {
        yield return new WaitForSeconds(1.2f);

        AddMessage("Hello! Thanks for your interest. I will get back to you soon.", isOwn: false, autoSend: true);
    }


    void SpawnBubble(ChatMessage msg)
    {
        GameObject prefab = msg.isOwn ? rightBubblePrefab : leftBubblePrefab;

        if (prefab == null)
        {
            Debug.LogError("[CHAT] Bubble prefab missing.");
            return;
        }

        GameObject bubble = Instantiate(prefab, messageContainer);

        TMP_Text msgText = bubble.GetComponentInChildren<TMP_Text>();
        if (msgText != null)
        {
            msgText.text = $"{msg.text}\n<size=10><color=#888888>{msg.timestamp}</color></size>";
        }
    }

    void ScrollToBottom()
    {
        // Wait one frame for layout to update then scroll
        StartCoroutine(ScrollCoroutine());
    }

    IEnumerator ScrollCoroutine()
    {
        yield return null;
        yield return new WaitForEndOfFrame();

        if (scrollRect == null)
        {
            Debug.LogWarning("[CHAT] ScrollRect is NULL");
            yield break;
        }

        if (scrollRect.content == null)
        {
            Debug.LogWarning("[CHAT] ScrollRect content is NULL");
            yield break;
        }

        Canvas.ForceUpdateCanvases();

        LayoutRebuilder.ForceRebuildLayoutImmediate(scrollRect.content);

        scrollRect.verticalNormalizedPosition = 0f;
    }

    // ── Local save/load ───────────────────────────────────────────────────

    void SaveMessages()
    {
        var wrapper = new ChatSaveWrapper { messages = messages };
        string json = JsonUtility.ToJson(wrapper);
        PlayerPrefs.SetString(ChatSaveKey, json);
        PlayerPrefs.Save();
    }

    void LoadMessages()
    {
        // Clear existing bubbles
        foreach (Transform child in messageContainer)
            Destroy(child.gameObject);
        messages.Clear();

        string json = PlayerPrefs.GetString(ChatSaveKey, "");
        if (string.IsNullOrEmpty(json)) return;

        var wrapper = JsonUtility.FromJson<ChatSaveWrapper>(json);
        if (wrapper?.messages == null) return;

        foreach (var msg in wrapper.messages)
        {
            messages.Add(msg);
            SpawnBubble(msg);
        }
    }

    [System.Serializable]
    class ChatMessage
    {
        public string text;
        public bool isOwn;
        public string timestamp;
    }

    [System.Serializable]
    class ChatSaveWrapper
    {
        public List<ChatMessage> messages;
    }
}