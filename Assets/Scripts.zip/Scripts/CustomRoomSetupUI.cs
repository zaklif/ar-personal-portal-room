using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class CustomRoomSetupUI : MonoBehaviour
{
    [Header("Panel")]
    public GameObject customRoomPanel;

    [Header("Toggle Button")]
    public GameObject customRoomToggleButton;

    [Header("Sliders")]
    public Slider widthSlider;
    public Slider heightSlider;
    public Slider depthSlider;
    public Slider redSlider;
    public Slider greenSlider;
    public Slider blueSlider;

    [Header("Extra Controls")]
    public Toggle ceilingToggle;

    [Header("Target Label")]
    public TMP_Text selectedTargetText;

    private CustomRoomBuilder currentBuilder;
    private bool isOwnerInside = false;

    private enum EditTarget
    {
        Wall,
        Floor,
        Ceiling
    }

    private EditTarget currentTarget = EditTarget.Wall;

    private void Start()
    {
        if (customRoomPanel != null)
            customRoomPanel.SetActive(false);

        if (customRoomToggleButton != null)
            customRoomToggleButton.SetActive(false);
    }

    public void RegisterRoom(CustomRoomBuilder builder)
    {
        currentBuilder = builder;

        if (currentBuilder == null)
            return;

        ModularRoomConfig config = currentBuilder.GetCurrentConfig();

        widthSlider.SetValueWithoutNotify(config.width);
        heightSlider.SetValueWithoutNotify(config.height);
        depthSlider.SetValueWithoutNotify(config.depth);

        redSlider.SetValueWithoutNotify(config.colorR);
        greenSlider.SetValueWithoutNotify(config.colorG);
        blueSlider.SetValueWithoutNotify(config.colorB);

        if (ceilingToggle != null)
            ceilingToggle.SetIsOnWithoutNotify(config.showCeiling);

        ConnectSliders();
        RefreshColorSliders();
        RefreshTargetLabel();
    }

    private void ConnectSliders()
    {
        widthSlider.onValueChanged.RemoveAllListeners();
        heightSlider.onValueChanged.RemoveAllListeners();
        depthSlider.onValueChanged.RemoveAllListeners();
        redSlider.onValueChanged.RemoveAllListeners();
        greenSlider.onValueChanged.RemoveAllListeners();
        blueSlider.onValueChanged.RemoveAllListeners();

        widthSlider.onValueChanged.AddListener(OnWidthChanged);
        heightSlider.onValueChanged.AddListener(OnHeightChanged);
        depthSlider.onValueChanged.AddListener(OnDepthChanged);
        redSlider.onValueChanged.AddListener(OnRedChanged);
        greenSlider.onValueChanged.AddListener(OnGreenChanged);
        blueSlider.onValueChanged.AddListener(OnBlueChanged);



        if (ceilingToggle != null)
        {
            ceilingToggle.onValueChanged.RemoveAllListeners();
            ceilingToggle.onValueChanged.AddListener(OnCeilingToggleChanged);
        }
    }

    public void SetOwnerInside(bool inside)
    {
        isOwnerInside = inside && RoomManager.IsOwner;

        if (customRoomToggleButton != null)
            customRoomToggleButton.SetActive(isOwnerInside);

        if (!isOwnerInside)
            HidePanel();
    }

    public void TogglePanel()
    {
        if (!isOwnerInside)
            return;

        if (customRoomPanel != null)
            customRoomPanel.SetActive(!customRoomPanel.activeSelf);
    }

    public void ShowPanel()
    {
        if (!isOwnerInside)
            return;

        if (customRoomPanel != null)
            customRoomPanel.SetActive(true);
    }

    public void HidePanel()
    {
        if (customRoomPanel != null)
            customRoomPanel.SetActive(false);
    }

    private void OnWidthChanged(float value)
    {
        if (currentBuilder != null)
            currentBuilder.SetWidth(value);
    }

    private void OnHeightChanged(float value)
    {
        if (currentBuilder != null)
            currentBuilder.SetHeight(value);
    }

    private void OnDepthChanged(float value)
    {
        if (currentBuilder != null)
            currentBuilder.SetDepth(value);
    }

    private void OnRedChanged(float value)
    {
        if (currentBuilder == null) return;

        ModularRoomConfig cfg = currentBuilder.GetCurrentConfig();

        switch (currentTarget)
        {
            case EditTarget.Wall:
                currentBuilder.SetWallColor(
                    value,
                    cfg.wallColorG,
                    cfg.wallColorB);
                break;

            case EditTarget.Floor:
                currentBuilder.SetFloorColor(
                    value,
                    cfg.floorColorG,
                    cfg.floorColorB);
                break;

            case EditTarget.Ceiling:
                currentBuilder.SetCeilingColor(
                    value,
                    cfg.ceilingColorG,
                    cfg.ceilingColorB);
                break;
        }
    }

    private void OnGreenChanged(float value)
    {
        if (currentBuilder == null) return;

        ModularRoomConfig cfg = currentBuilder.GetCurrentConfig();

        switch (currentTarget)
        {
            case EditTarget.Wall:
                currentBuilder.SetWallColor(
                    cfg.wallColorR,
                    value,
                    cfg.wallColorB);
                break;

            case EditTarget.Floor:
                currentBuilder.SetFloorColor(
                    cfg.floorColorR,
                    value,
                    cfg.floorColorB);
                break;

            case EditTarget.Ceiling:
                currentBuilder.SetCeilingColor(
                    cfg.ceilingColorR,
                    value,
                    cfg.ceilingColorB);
                break;
        }
    }

    private void OnBlueChanged(float value)
    {
        if (currentBuilder == null) return;

        ModularRoomConfig cfg = currentBuilder.GetCurrentConfig();

        switch (currentTarget)
        {
            case EditTarget.Wall:
                currentBuilder.SetWallColor(
                    cfg.wallColorR,
                    cfg.wallColorG,
                    value);
                break;

            case EditTarget.Floor:
                currentBuilder.SetFloorColor(
                    cfg.floorColorR,
                    cfg.floorColorG,
                    value);
                break;

            case EditTarget.Ceiling:
                currentBuilder.SetCeilingColor(
                    cfg.ceilingColorR,
                    cfg.ceilingColorG,
                    value);
                break;
        }
    }

    public void ApplyTexture(string textureName)
    {
        if (currentBuilder == null)
            return;

        switch (currentTarget)
        {
            case EditTarget.Wall:
                currentBuilder.SetWallTexture(textureName);
                break;

            case EditTarget.Floor:
                currentBuilder.SetFloorTexture(textureName);
                break;

            case EditTarget.Ceiling:
                currentBuilder.SetCeilingTexture(textureName);
                break;
        }
    }

    public void ApplyPlainTexture() => ApplyTexture("Plain");
    public void ApplyWoodTexture() => ApplyTexture("Wood");
    public void ApplyConcreteTexture() => ApplyTexture("Concrete");
    public void ApplyMarbleTexture() => ApplyTexture("Marble");

    private void OnCeilingToggleChanged(bool value)
    {
        if (currentBuilder != null)
        {
            currentBuilder.ToggleCeiling(value);
        }
    }

    public void SelectWallMode()
    {
        currentTarget = EditTarget.Wall;
        RefreshColorSliders();
        RefreshTargetLabel();
    }

    public void SelectFloorMode()
    {
        currentTarget = EditTarget.Floor;
        RefreshColorSliders();
        RefreshTargetLabel();
    }

    public void SelectCeilingMode()
    {
        currentTarget = EditTarget.Ceiling;
        RefreshColorSliders();
        RefreshTargetLabel();
    }

    private void RefreshColorSliders()
    {
        if (currentBuilder == null) return;

        ModularRoomConfig cfg = currentBuilder.GetCurrentConfig();

        switch (currentTarget)
        {
            case EditTarget.Wall:
                redSlider.SetValueWithoutNotify(cfg.wallColorR);
                greenSlider.SetValueWithoutNotify(cfg.wallColorG);
                blueSlider.SetValueWithoutNotify(cfg.wallColorB);
                break;

            case EditTarget.Floor:
                redSlider.SetValueWithoutNotify(cfg.floorColorR);
                greenSlider.SetValueWithoutNotify(cfg.floorColorG);
                blueSlider.SetValueWithoutNotify(cfg.floorColorB);
                break;

            case EditTarget.Ceiling:
                redSlider.SetValueWithoutNotify(cfg.ceilingColorR);
                greenSlider.SetValueWithoutNotify(cfg.ceilingColorG);
                blueSlider.SetValueWithoutNotify(cfg.ceilingColorB);
                break;
        }
    }

    private void RefreshTargetLabel()
    {
        if (selectedTargetText == null) return;

        selectedTargetText.text = "Editing: " + currentTarget.ToString();
    }

    public void ResetSize()
    {
        if (currentBuilder == null) return;

        currentBuilder.ResetSize();

        ModularRoomConfig cfg = currentBuilder.GetCurrentConfig();

        widthSlider.SetValueWithoutNotify(cfg.width);
        heightSlider.SetValueWithoutNotify(cfg.height);
        depthSlider.SetValueWithoutNotify(cfg.depth);
    }

    public void ResetCurrentColor()
    {
        if (currentBuilder == null) return;

        currentBuilder.ResetCurrentTargetColor(currentTarget.ToString());
        RefreshColorSliders();
    }

    public void ResetCurrentTexture()
    {
        if (currentBuilder == null) return;

        currentBuilder.ResetCurrentTargetTexture(currentTarget.ToString());
    }

    public void ResetAll()
    {
        if (currentBuilder == null) return;

        currentBuilder.ResetAllCustomRoom();

        ModularRoomConfig cfg = currentBuilder.GetCurrentConfig();

        widthSlider.SetValueWithoutNotify(cfg.width);
        heightSlider.SetValueWithoutNotify(cfg.height);
        depthSlider.SetValueWithoutNotify(cfg.depth);

        if (ceilingToggle != null)
            ceilingToggle.SetIsOnWithoutNotify(cfg.showCeiling);

        RefreshColorSliders();
        RefreshTargetLabel();
    }

    ////PRESETTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
    public void ApplyDefaultPreset()
    {
        if (currentBuilder == null) return;
        currentBuilder.ApplyDefaultPreset();
        RefreshColorSliders();
    }

    public void ApplyModernPreset()
    {
        if (currentBuilder == null) return;
        currentBuilder.ApplyModernPreset();
        RefreshColorSliders();
    }

    public void ApplyWoodPreset()
    {
        if (currentBuilder == null) return;
        currentBuilder.ApplyWoodPreset();
        RefreshColorSliders();
    }

    public void ApplyConcretePreset()
    {
        if (currentBuilder == null) return;
        currentBuilder.ApplyConcretePreset();
        RefreshColorSliders();
    }

    public void ApplyMarblePreset()
    {
        if (currentBuilder == null) return;
        currentBuilder.ApplyMarblePreset();
        RefreshColorSliders();
    }

    //END PRESETTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT

}