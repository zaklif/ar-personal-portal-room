﻿

//using System.Collections.Generic;
//using System.IO;
//using Unity.VisualScripting;
//using UnityEngine;

//public class RoomManager : MonoBehaviour
//{
//    public static RoomManager Instance { get; private set; }
//    public RoomData CurrentRoom { get; private set; }
//    public static bool IsOwner { get; private set; } = false;

//    private string deviceId;
//    private string saveFolder;

//    void Awake()
//    {
//        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
//        Instance = this;
//        DontDestroyOnLoad(gameObject);

//        deviceId = PlayerPrefs.GetString("DeviceId", "");
//        if (string.IsNullOrEmpty(deviceId))
//        {
//            deviceId = System.Guid.NewGuid().ToString("N").Substring(0, 12).ToUpper();
//            PlayerPrefs.SetString("DeviceId", deviceId);
//            PlayerPrefs.Save();
//        }

//        saveFolder = Path.Combine(Application.persistentDataPath, "Rooms");
//        if (!Directory.Exists(saveFolder))
//            Directory.CreateDirectory(saveFolder);

//        Debug.Log($"[ROOM MGR] Device ID: {deviceId}");
//    }

//    public RoomData CreateNewRoom(string templateName = "")
//    {
//        string newId = GenerateRoomId();
//        CurrentRoom = new RoomData
//        {
//            roomId = newId,
//            ownerId = deviceId,
//            roomTemplateName = templateName,
//            objects = new List<PlacedObjectData>(),
//            shelves = new List<PlacedShelfData>()
//        };
//        IsOwner = true;
//        SaveCurrentRoom();
//        Debug.Log($"[ROOM MGR] Created: {newId} template: {templateName}");
//        return CurrentRoom;
//    }

//    public RoomData LoadRoom(string roomId)
//    {
//        roomId = roomId.Trim().ToUpper();
//        string path = GetRoomFilePath(roomId);
//        if (!File.Exists(path)) { Debug.LogWarning($"[ROOM MGR] Room '{roomId}' not found."); return null; }
//        string json = File.ReadAllText(path);
//        RoomData data = JsonUtility.FromJson<RoomData>(json);
//        CurrentRoom = data;
//        IsOwner = (data.ownerId == deviceId);
//        Debug.Log($"[ROOM MGR] Loaded: {roomId} | Owner: {IsOwner}");
//        return data;
//    }

//    public void SaveCurrentRoom()
//    {
//        if (CurrentRoom == null || !IsOwner) return;
//        string path = GetRoomFilePath(CurrentRoom.roomId);
//        File.WriteAllText(path, JsonUtility.ToJson(CurrentRoom, prettyPrint: true));
//        Debug.Log($"[ROOM MGR] Saved: {CurrentRoom.roomId} | Objects: {CurrentRoom.objects.Count}");
//    }

//    public void AddObjectToRoom(PlacedObjectData data)
//    {
//        if (CurrentRoom == null || !IsOwner) return;
//        CurrentRoom.objects.Add(data);
//        SaveCurrentRoom();
//    }

//    public void RemoveObjectFromRoom(PlacedObjectData data)
//    {
//        if (CurrentRoom == null || !IsOwner) return;
//        // Remove by filename match
//        CurrentRoom.objects.RemoveAll(o => o.fileName == data.fileName);
//        SaveCurrentRoom();
//    }

//    // NEW: Update metadata for an existing object
//    public void UpdateObjectMeta(ObjectMetaData meta)
//    {
//        if (CurrentRoom == null || !IsOwner) return;

//        // Find the matching object by the GameObject name (which matches fileName)
//        string fileName = meta.gameObject.name + ".glb";

//        // Try exact match first then partial
//        var obj = CurrentRoom.objects.Find(o => o.fileName == meta.gameObject.name)
//               ?? CurrentRoom.objects.Find(o => meta.gameObject.name.Contains(
//                   System.IO.Path.GetFileNameWithoutExtension(o.fileName)));

//        if (obj != null)
//        {
//            obj.objectName = meta.objectName;
//            obj.description = meta.description;
//            obj.objectType = (int)meta.objectType;
//            obj.price = meta.price;
//            obj.currency = meta.currency;
//            SaveCurrentRoom();
//            Debug.Log($"[ROOM MGR] Updated meta for: {meta.objectName}");
//        }
//        else
//        {
//            Debug.LogWarning($"[ROOM MGR] Could not find object to update meta: {meta.gameObject.name}");
//        }
//    }

//    public void AddShelfToRoom(PlacedShelfData data)
//    {
//        if (CurrentRoom == null || !IsOwner) return;
//        CurrentRoom.shelves.Add(data);
//        SaveCurrentRoom();
//    }

//    public void RemoveShelfFromRoom(PlacedShelfData data)
//    {
//        if (CurrentRoom == null || !IsOwner) return;
//        CurrentRoom.shelves.Remove(data);
//        SaveCurrentRoom();
//    }

//    public string GetDeviceId() => deviceId;

//    string GenerateRoomId()
//    {
//        const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
//        string id;
//        do
//        {
//            char[] result = new char[6];
//            for (int i = 0; i < 6; i++)
//                result[i] = chars[Random.Range(0, chars.Length)];
//            id = new string(result);
//        }
//        while (File.Exists(GetRoomFilePath(id)));
//        return id;
//    }

//    string GetRoomFilePath(string roomId) =>
//        Path.Combine(saveFolder, roomId.ToUpper() + ".json");
//}

using UnityEngine;
using System.IO;
using System.Collections.Generic;

public class RoomManager : MonoBehaviour
{
    public static RoomManager Instance { get; private set; }
    public RoomData CurrentRoom { get; private set; }
    public static bool IsOwner { get; private set; } = false;

    private string deviceId;
    private string saveFolder;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        deviceId = PlayerPrefs.GetString("DeviceId", "");
        if (string.IsNullOrEmpty(deviceId))
        {
            deviceId = System.Guid.NewGuid().ToString("N").Substring(0, 12).ToUpper();
            PlayerPrefs.SetString("DeviceId", deviceId);
            PlayerPrefs.Save();
        }

        saveFolder = Path.Combine(Application.persistentDataPath, "Rooms");
        if (!Directory.Exists(saveFolder))
            Directory.CreateDirectory(saveFolder);

        Debug.Log($"[ROOM MGR] Device ID: {deviceId}");
    }

    public RoomData CreateNewRoom(string templateName = "")
    {
        string newId = GenerateRoomId();
        CurrentRoom = new RoomData
        {
            roomId = newId,
            ownerId = deviceId,
            roomTemplateName = templateName,
            objects = new List<PlacedObjectData>(),
            shelves = new List<PlacedShelfData>()
        };
        IsOwner = true;
        SaveCurrentRoom();
        Debug.Log($"[ROOM MGR] Created: {newId}");
        return CurrentRoom;
    }

    public RoomData LoadRoom(string roomId)
    {
        roomId = roomId.Trim().ToUpper();
        string path = GetRoomFilePath(roomId);
        if (!File.Exists(path)) { Debug.LogWarning($"[ROOM MGR] Room '{roomId}' not found."); return null; }
        RoomData data = JsonUtility.FromJson<RoomData>(File.ReadAllText(path));
        CurrentRoom = data;
        IsOwner = (data.ownerId == deviceId);
        Debug.Log($"[ROOM MGR] Loaded: {roomId} | Owner: {IsOwner}");
        return data;
    }

    public void SaveCurrentRoom()
    {
        if (CurrentRoom == null || !IsOwner) return;
        File.WriteAllText(GetRoomFilePath(CurrentRoom.roomId),
            JsonUtility.ToJson(CurrentRoom, prettyPrint: true));
        Debug.Log($"[ROOM MGR] Saved: {CurrentRoom.roomId} | Objects: {CurrentRoom.objects.Count}");
    }

    public void AddObjectToRoom(PlacedObjectData data)
    {
        if (CurrentRoom == null || !IsOwner) return;
        CurrentRoom.objects.Add(data);
        SaveCurrentRoom();
        Debug.Log($"[ROOM MGR] Added object: {data.objectName} id={data.instanceId}");
    }

    public void RemoveObjectFromRoom(string instanceId)
    {
        if (CurrentRoom == null || !IsOwner) return;
        int removed = CurrentRoom.objects.RemoveAll(o => o.instanceId == instanceId);
        if (removed > 0) SaveCurrentRoom();
        Debug.Log($"[ROOM MGR] Removed object id={instanceId}");
    }

    // FIX: use instanceId for reliable lookup
    public void UpdateObjectMeta(ObjectMetaData meta)
    {
        if (CurrentRoom == null || !IsOwner) return;

        var obj = CurrentRoom.objects.Find(o => o.instanceId == meta.instanceId);
        if (obj != null)
        {
            obj.objectName = meta.objectName;
            obj.description = meta.description;
            obj.objectType = (int)meta.objectType;
            obj.price = meta.price;
            obj.currency = meta.currency;
            SaveCurrentRoom();
            Debug.Log($"[ROOM MGR] Updated meta: {meta.objectName} | {meta.objectType} | {meta.price} | id={meta.instanceId}");
        }
        else
        {
            Debug.LogWarning($"[ROOM MGR] Object not found for id={meta.instanceId}. Trying to add.");
        }
    }

    public void AddShelfToRoom(PlacedShelfData data)
    {
        if (CurrentRoom == null || !IsOwner) return;
        CurrentRoom.shelves.Add(data);
        SaveCurrentRoom();
    }

    public void RemoveShelfFromRoom(PlacedShelfData data)
    {
        if (CurrentRoom == null || !IsOwner) return;
        CurrentRoom.shelves.Remove(data);
        SaveCurrentRoom();
    }

    public string GetDeviceId() => deviceId;

    string GenerateRoomId()
    {
        const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        string id;
        do
        {
            char[] result = new char[6];
            for (int i = 0; i < 6; i++)
                result[i] = chars[Random.Range(0, chars.Length)];
            id = new string(result);
        }
        while (File.Exists(GetRoomFilePath(id)));
        return id;
    }

    string GetRoomFilePath(string roomId) =>
        Path.Combine(saveFolder, roomId.ToUpper() + ".json");
}