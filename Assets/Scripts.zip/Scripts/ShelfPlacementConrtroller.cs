﻿//using UnityEngine;
//using UnityEngine.InputSystem.EnhancedTouch;
//using System.Collections.Generic;
//using TMPro;
//using UnityEngine.UI;
//using Touch = UnityEngine.InputSystem.EnhancedTouch.Touch;

///// <summary>
///// Handles placing shelves on walls and placing objects on shelf surfaces.
/////
///// SETUP:
///// 1. Attach this script to a Manager GameObject in the scene.
///// 2. Assign your shelf prefab — it should have:
/////    - A MeshCollider or BoxCollider on the shelf surface (for object placement raycasting).
/////    - A tag "Shelf" on the root.
///// 3. Assign the UI references (Add Shelf button, confirm/cancel panel).
///// 4. The room mesh collider is used for wall raycasting — make sure your room
/////    mesh has a MeshCollider (non-trigger) on it.
///// 5. Link ObjectPlacementController so objects know to use shelf surfaces.
/////
///// WORKFLOW:
///// Outside room  ? "Add Shelf" button is hidden.
///// Walk inside   ? "Add Shelf" button appears (called from RoomInsideDetector events).
///// Press button  ? Tap a wall ? shelf preview snaps to wall.
///// Press Confirm ? Shelf is placed permanently.
///// Press Cancel  ? Shelf removed.
///// </summary>
//public class ShelfPlacementController : MonoBehaviour
//{
//    [Header("Shelf Prefab")]
//    [SerializeField] private GameObject shelfPrefab;

//    [Header("UI")]
//    [SerializeField] private GameObject addShelfButton;       // shown only when inside
//    [SerializeField] private GameObject shelfConfirmPanel;    // Confirm / Cancel buttons

//    [Header("Wall Detection")]
//    [Tooltip("Layer mask for wall raycasting. Set your room mesh to a 'Wall' layer.")]
//    [SerializeField] private LayerMask wallLayerMask;

//    [Tooltip("How far from wall surface the shelf is offset (so it sits flush).")]
//    [SerializeField] private float wallOffset = 0.02f;

//    [Tooltip("Height above floor to clamp shelf placement (min).")]
//    [SerializeField] private float minShelfHeight = 0.5f;

//    [Tooltip("Height above floor to clamp shelf placement (max).")]
//    [SerializeField] private float maxShelfHeight = 2.0f;

//    [Header("References")]
//    [SerializeField] private ObjectPlacementController objectPlacementController;

//    // Internal state
//    private bool isPlacingShelf = false;
//    private GameObject previewShelf = null;

//    // All placed shelves in the room
//    private List<GameObject> placedShelves = new List<GameObject>();

//    void OnEnable() => EnhancedTouchSupport.Enable();
//    void OnDisable() => EnhancedTouchSupport.Disable();

//    void Start()
//    {
//        addShelfButton.SetActive(false);
//        shelfConfirmPanel.SetActive(false);
//    }

//    // ??? Called by RoomInsideDetector events ???????????????????????????????

//    public void OnEnteredRoom()
//    {
//        addShelfButton.SetActive(true);

//        // Add this line:
//        objectPlacementController.ShowBottomBar();

//        Debug.Log("[SHELF] Inside room — shelf button visible");
//    }

//    public void OnExitedRoom()
//    {
//        addShelfButton.SetActive(false);

//        // Add this line:
//        objectPlacementController.HideBottomBar();

//        // Cancel any in-progress shelf placement
//        if (isPlacingShelf)
//            OnCancelShelf();

//        Debug.Log("[SHELF] Left room — shelf button hidden");
//    }

//    // ??? Called by "Add Shelf" button ??????????????????????????????????????

//    public void OnAddShelfButtonPressed()
//    {
//        if (!RoomInsideDetector.IsInsideRoom)
//        {
//            Debug.LogWarning("[SHELF] Not inside room — cannot add shelf.");
//            return;
//        }

//        isPlacingShelf = true;
//        addShelfButton.SetActive(false);
//        Debug.Log("[SHELF] Tap a wall to place shelf.");
//    }

//    // ??? Update: wall raycast for shelf placement ??????????????????????????

//    void Update()
//    {
//        if (!isPlacingShelf) return;

//        var activeTouches = Touch.activeTouches;
//        if (activeTouches.Count == 0) return;

//        var touch = activeTouches[0];
//        if (touch.phase != UnityEngine.InputSystem.TouchPhase.Began) return;

//        Ray ray = Camera.main.ScreenPointToRay(touch.screenPosition);

//        if (Physics.Raycast(ray, out RaycastHit hit, 10f, wallLayerMask))
//        {
//            Vector3 normal = hit.normal;

//            // Only snap to vertical surfaces (walls), ignore floor/ceiling
//            if (Mathf.Abs(normal.y) > 0.7f)
//            {
//                Debug.Log("[SHELF] Hit floor/ceiling — tap a wall instead.");
//                return;
//            }

//            Vector3 spawnPos = hit.point + normal * wallOffset;

//            // Clamp height
//            spawnPos.y = Mathf.Clamp(spawnPos.y, minShelfHeight, maxShelfHeight);

//            // Rotate shelf to face away from the wall
//            // Keep your prefab's original rotation, only rotate around Y axis to face away from wall
//            float wallAngle = Mathf.Atan2(-normal.x, -normal.z) * Mathf.Rad2Deg;
//            Quaternion spawnRot = Quaternion.Euler(-90f, wallAngle + 90f, 90f);// try +90, -90, +180

//            PlaceShelfPreview(spawnPos, spawnRot);
//        }
//        else
//        {
//            Debug.Log("[SHELF] No wall hit — try tapping closer to a wall.");
//        }
//    }

//    void PlaceShelfPreview(Vector3 pos, Quaternion rot)
//    {
//        // Remove old preview if user taps again before confirming
//        if (previewShelf != null)
//            Destroy(previewShelf);

//        previewShelf = Instantiate(shelfPrefab, pos, rot);
//        previewShelf.transform.localScale = Vector3.one * 0.3f; // ← add this, adjust 0.3f until size looks right

//        shelfConfirmPanel.SetActive(true);

//        Debug.Log($"[SHELF] Preview placed at {pos}");
//    }

//    // ??? Confirm / Cancel ??????????????????????????????????????????????????

//    public void OnConfirmShelf()
//    {
//        if (previewShelf == null) return;

//        placedShelves.Add(previewShelf);
//        previewShelf = null;

//        isPlacingShelf = false;
//        shelfConfirmPanel.SetActive(false);
//        addShelfButton.SetActive(true);

//        // Tell ObjectPlacementController shelves exist for surface-snapping
//        objectPlacementController.RefreshShelfSurfaces(placedShelves);

//        Debug.Log($"[SHELF] Shelf confirmed. Total shelves: {placedShelves.Count}");
//    }

//    public void OnCancelShelf()
//    {
//        if (previewShelf != null)
//        {
//            Destroy(previewShelf);
//            previewShelf = null;
//        }

//        isPlacingShelf = false;
//        shelfConfirmPanel.SetActive(false);
//        addShelfButton.SetActive(RoomInsideDetector.IsInsideRoom);

//        Debug.Log("[SHELF] Shelf placement cancelled.");
//    }

//    // ??? Remove a specific shelf (and its objects) ?????????????????????????

//    public void RemoveShelf(GameObject shelf)
//    {
//        placedShelves.Remove(shelf);
//        Destroy(shelf);
//        objectPlacementController.RefreshShelfSurfaces(placedShelves);
//        Debug.Log("[SHELF] Shelf removed.");
//    }
//    public void SetVisitorMode(bool visitor)
//    {
//        if (visitor)
//        {
//            addShelfButton.SetActive(false);
//            isPlacingShelf = false;
//        }
//    }
//}
using UnityEngine;
using UnityEngine.InputSystem.EnhancedTouch;
using System.Collections.Generic;
using TMPro;
using UnityEngine.UI;
using Touch = UnityEngine.InputSystem.EnhancedTouch.Touch;

public class ShelfPlacementController : MonoBehaviour
{
    [Header("Shelf Prefab")]
    [SerializeField] private GameObject shelfPrefab;

    [Header("UI")]
    [SerializeField] private GameObject addShelfButton;
    [SerializeField] private GameObject shelfConfirmPanel;

    [Header("Wall Detection")]
    [SerializeField] private LayerMask wallLayerMask;
    [SerializeField] private float wallOffset = 0.02f;
    [SerializeField] private float minShelfHeight = 0.5f;
    [SerializeField] private float maxShelfHeight = 2.0f;

    [Header("References")]
    [SerializeField] private ObjectPlacementController objectPlacementController;

    private bool isPlacingShelf = false;
    private bool isVisitorMode = false;
    private GameObject previewShelf = null;
    private List<GameObject> placedShelves = new List<GameObject>();

    // Reference to the spawned room — needed for local position saving
    private GameObject portalRoom = null;

    void OnEnable() => EnhancedTouchSupport.Enable();
    void OnDisable() => EnhancedTouchSupport.Disable();

    void Start()
    {
        addShelfButton.SetActive(false);
        shelfConfirmPanel.SetActive(false);
    }

    // Called by doorFramePlacementController after room spawns
    public void SetPortalRoom(GameObject room)
    {
        portalRoom = room;
        Debug.Log("[SHELF] Portal room set: " + room.name);
    }

    public void SetVisitorMode(bool visitor)
    {
        isVisitorMode = visitor;
        if (visitor) addShelfButton.SetActive(false);
    }

    // ── Called by RoomInsideDetector ──────────────────────────────────────

    public void OnEnteredRoom()
    {
        if (isVisitorMode) return;
        addShelfButton.SetActive(true);
        objectPlacementController.ShowBottomBar();
        Debug.Log("[SHELF] Inside room — shelf button visible");
    }

    public void OnExitedRoom()
    {
        addShelfButton.SetActive(false);
        objectPlacementController.HideBottomBar();
        if (isPlacingShelf) OnCancelShelf();
        Debug.Log("[SHELF] Left room — shelf button hidden");
    }

    // ── Add Shelf button ──────────────────────────────────────────────────

    public void OnAddShelfButtonPressed()
    {
        if (isVisitorMode || !RoomInsideDetector.IsInsideRoom) return;
        isPlacingShelf = true;
        addShelfButton.SetActive(false);
        Debug.Log("[SHELF] Tap a wall to place shelf.");
    }

    // ── Update: wall raycast ──────────────────────────────────────────────

    void Update()
    {
        if (!isPlacingShelf) return;

        var activeTouches = Touch.activeTouches;
        if (activeTouches.Count == 0) return;
        var touch = activeTouches[0];
        if (touch.phase != UnityEngine.InputSystem.TouchPhase.Began) return;

        Ray ray = Camera.main.ScreenPointToRay(touch.screenPosition);
        if (Physics.Raycast(ray, out RaycastHit hit, 10f, wallLayerMask))
        {
            Vector3 normal = hit.normal;
            if (Mathf.Abs(normal.y) > 0.7f)
            {
                Debug.Log("[SHELF] Hit floor/ceiling — tap a wall.");
                return;
            }

            Vector3 spawnPos = hit.point + normal * wallOffset;
            spawnPos.y = Mathf.Clamp(spawnPos.y, minShelfHeight, maxShelfHeight);

            float wallAngle = Mathf.Atan2(-normal.x, -normal.z) * Mathf.Rad2Deg;
            Quaternion spawnRot = Quaternion.Euler(-90f, wallAngle + 90f, 90f);

           

            PlaceShelfPreview(spawnPos, spawnRot);
        }
        else
        {
            Debug.Log("[SHELF] No wall hit.");
        }
    }

    void PlaceShelfPreview(Vector3 pos, Quaternion rot)
    {
        if (previewShelf != null)
            Destroy(previewShelf);

        previewShelf = Instantiate(shelfPrefab, pos, rot);

        // ADD THIS BACK
        previewShelf.transform.localScale = Vector3.one * 0.3f;

        shelfConfirmPanel.SetActive(true);

        Debug.Log($"[SHELF] Preview at {pos}");
    }

    // ── Confirm / Cancel ──────────────────────────────────────────────────

    public void OnConfirmShelf()
    {
        if (previewShelf == null) return;

        // FIX: Parent shelf to room so it moves with room
        if (portalRoom != null)
            previewShelf.transform.SetParent(portalRoom.transform);

        placedShelves.Add(previewShelf);

        // FIX: Save shelf using LOCAL position relative to room
        SaveShelfToRoom(previewShelf);

        previewShelf = null;
        isPlacingShelf = false;
        shelfConfirmPanel.SetActive(false);
        addShelfButton.SetActive(true);

        objectPlacementController.RefreshShelfSurfaces(placedShelves);
        Debug.Log($"[SHELF] Confirmed. Total: {placedShelves.Count}");
    }

    public void OnCancelShelf()
    {
        if (previewShelf != null) { Destroy(previewShelf); previewShelf = null; }
        isPlacingShelf = false;
        shelfConfirmPanel.SetActive(false);
        addShelfButton.SetActive(RoomInsideDetector.IsInsideRoom && !isVisitorMode);
        Debug.Log("[SHELF] Cancelled.");
    }

    // ── Save shelf to RoomManager ─────────────────────────────────────────

    void SaveShelfToRoom(GameObject shelf)
    {
        if (RoomManager.Instance == null || !RoomManager.IsOwner) return;

        // Save LOCAL position relative to room (same as objects)
        Vector3 localPos = shelf.transform.localPosition;
        Quaternion localRot = shelf.transform.localRotation;
        Vector3 localScale = shelf.transform.localScale;

        RoomManager.Instance.AddShelfToRoom(new PlacedShelfData
        {
            posX = localPos.x,
            posY = localPos.y,
            posZ = localPos.z,
            rotX = localRot.x,
            rotY = localRot.y,
            rotZ = localRot.z,
            rotW = localRot.w,
            scaleX = localScale.x,
            scaleY = localScale.y,
            scaleZ = localScale.z
        });

        Debug.Log($"[SHELF] Saved local pos={localPos}");
    }

    // ── Restore shelves (called by RoomLoader) ────────────────────────────

    public void RestoreShelves(List<PlacedShelfData> shelfDataList, GameObject room)
    {
        if (shelfDataList == null || shelfDataList.Count == 0) return;

        portalRoom = room;

        foreach (var data in shelfDataList)
        {
            GameObject shelf = Instantiate(shelfPrefab);

            // Parent to room then apply local position
            shelf.transform.SetParent(room.transform);
            shelf.transform.localPosition = new Vector3(data.posX, data.posY, data.posZ);
            shelf.transform.localRotation = new Quaternion(data.rotX, data.rotY, data.rotZ, data.rotW);
            shelf.transform.localScale = new Vector3(data.scaleX, data.scaleY, data.scaleZ);

            placedShelves.Add(shelf);
            Debug.Log($"[SHELF] Restored at local pos={shelf.transform.localPosition}");
        }

        // Tell ObjectPlacementController shelves exist
        objectPlacementController.RefreshShelfSurfaces(placedShelves);
        Debug.Log($"[SHELF] {placedShelves.Count} shelf(ves) restored.");
    }

    public void RemoveShelf(GameObject shelf)
    {
        placedShelves.Remove(shelf);
        Destroy(shelf);
        objectPlacementController.RefreshShelfSurfaces(placedShelves);
    }
}