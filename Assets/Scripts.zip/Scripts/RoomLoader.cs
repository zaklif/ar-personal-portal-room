﻿
//using UnityEngine;
//using System.Collections;
//using System.IO;

//public class RoomLoader : MonoBehaviour
//{
//    [Header("References")]
//    [SerializeField] private ObjectPlacementController objectPlacementController;
//    [SerializeField] private ShelfPlacementController shelfPlacementController;

//    [Header("Room ID Display")]
//    [SerializeField] private TMPro.TMP_Text roomIdDisplayText;
//    [SerializeField] private TMPro.TMP_Text roomModeText;

//    [Header("GLB Loading")]
//    [SerializeField] private GlbFileLoader glbFileLoader;

//    private RoomData currentRoomData;
//    private bool isVisitMode = false;
//    private GameObject spawnedRoom;

//    void Start()
//    {
//        string intent = PlayerPrefs.GetString("RoomIntent", "create");
//        string roomId = PlayerPrefs.GetString("ActiveRoomId", "");

//        isVisitMode = (intent == "visit");

//        if (string.IsNullOrEmpty(roomId))
//        {
//            currentRoomData = RoomManager.Instance.CreateNewRoom();
//            isVisitMode = false;
//        }
//        else
//        {
//            currentRoomData = RoomManager.Instance.LoadRoom(roomId);
//            if (currentRoomData == null)
//            {
//                currentRoomData = RoomManager.Instance.CreateNewRoom();
//                isVisitMode = false;
//            }
//        }

//        if (roomIdDisplayText != null)
//            roomIdDisplayText.text = "ID: " + currentRoomData.roomId;

//        if (roomModeText != null)
//            roomModeText.text = isVisitMode ? "VISITING" : "MY ROOM";

//        if (isVisitMode)
//            LockEditingForVisitor();

//        Debug.Log($"[ROOM LOADER] Room:{currentRoomData.roomId} | Mode:{(isVisitMode ? "VISIT" : "OWNER")} | Objects:{currentRoomData.objects.Count} | Shelves:{currentRoomData.shelves.Count}");
//    }

//    // Called by doorFramePlacementController — receives the spawned room GameObject
//    public void OnRoomPortalPlaced(GameObject roomObject = null)
//    {
//        spawnedRoom = roomObject;

//        if (currentRoomData == null) return;

//        // Tell ShelfPlacementController which room was spawned
//        if (shelfPlacementController != null)
//            shelfPlacementController.SetPortalRoom(spawnedRoom);

//        // Restore shelves FIRST — objects may be placed on shelves
//        if (currentRoomData.shelves != null && currentRoomData.shelves.Count > 0)
//            shelfPlacementController?.RestoreShelves(currentRoomData.shelves, spawnedRoom);

//        // Then restore objects
//        if (currentRoomData.objects.Count > 0)
//            StartCoroutine(RestoreObjectsCoroutine());
//        else
//            Debug.Log("[ROOM LOADER] No objects to restore.");
//    }

//    IEnumerator RestoreObjectsCoroutine()
//    {
//        yield return null; // wait one frame

//        Debug.Log($"[ROOM LOADER] Restoring {currentRoomData.objects.Count} objects...");

//        foreach (var objData in currentRoomData.objects)
//        {
//            yield return StartCoroutine(LoadAndPlaceObject(objData));
//            yield return null;
//        }

//        Debug.Log("[ROOM LOADER] All objects restored.");
//    }

//    IEnumerator LoadAndPlaceObject(PlacedObjectData data)
//    {
//        if (glbFileLoader == null) { Debug.LogError("[ROOM LOADER] GlbFileLoader not assigned!"); yield break; }

//        string filePath = Path.Combine(Application.persistentDataPath, "UploadedModels", data.fileName);

//        if (!File.Exists(filePath)) { Debug.LogWarning($"[ROOM LOADER] File not found: {filePath}"); yield break; }

//        bool loaded = false;
//        GameObject loadedObj = null;

//        glbFileLoader.LoadFile(filePath, (obj) => { loadedObj = obj; loaded = true; });

//        float elapsed = 0f;
//        while (!loaded && elapsed < 10f) { elapsed += Time.deltaTime; yield return null; }

//        if (loadedObj == null) { Debug.LogWarning($"[ROOM LOADER] Load failed: {data.fileName}"); yield break; }

//        // Parent to room then apply local position
//        if (spawnedRoom != null)
//        {
//            loadedObj.transform.SetParent(spawnedRoom.transform);
//            loadedObj.transform.localPosition = new Vector3(data.posX, data.posY, data.posZ);
//            loadedObj.transform.localRotation = new Quaternion(data.rotX, data.rotY, data.rotZ, data.rotW);
//            loadedObj.transform.localScale = new Vector3(data.scaleX, data.scaleY, data.scaleZ);
//        }
//        else
//        {
//            loadedObj.transform.position = new Vector3(data.posX, data.posY, data.posZ);
//            loadedObj.transform.rotation = new Quaternion(data.rotX, data.rotY, data.rotZ, data.rotW);
//            loadedObj.transform.localScale = new Vector3(data.scaleX, data.scaleY, data.scaleZ);
//        }

//        if (!isVisitMode && objectPlacementController != null)
//            objectPlacementController.RegisterRestoredObject(loadedObj, data.fileName);

//        Debug.Log($"[ROOM LOADER] Restored: {data.fileName} at local={loadedObj.transform.localPosition}");
//    }

//    void LockEditingForVisitor()
//    {
//        if (objectPlacementController != null)
//        {
//            objectPlacementController.HideBottomBar();
//            objectPlacementController.SetVisitorMode(true);
//        }
//        if (shelfPlacementController != null)
//            shelfPlacementController.SetVisitorMode(true);
//    }
//}

using UnityEngine;
using System.Collections;
using System.IO;

public class RoomLoader : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private ObjectPlacementController objectPlacementController;
    [SerializeField] private ShelfPlacementController shelfPlacementController;

    [Header("Room ID Display")]
    [SerializeField] private TMPro.TMP_Text roomIdDisplayText;
    [SerializeField] private TMPro.TMP_Text roomModeText;

    [Header("GLB Loading")]
    [SerializeField] private GlbFileLoader glbFileLoader;

    private RoomData currentRoomData;
    private bool isVisitMode = false;
    private GameObject spawnedRoom;

    void Start()
    {
        string intent = PlayerPrefs.GetString("RoomIntent", "create");
        string roomId = PlayerPrefs.GetString("ActiveRoomId", "");

        isVisitMode = (intent == "visit");

        if (string.IsNullOrEmpty(roomId))
        {
            currentRoomData = RoomManager.Instance.CreateNewRoom();
            isVisitMode = false;
        }
        else
        {
            currentRoomData = RoomManager.Instance.LoadRoom(roomId);
            if (currentRoomData == null)
            {
                currentRoomData = RoomManager.Instance.CreateNewRoom();
                isVisitMode = false;
            }
        }

        if (roomIdDisplayText != null)
            roomIdDisplayText.text = "ID: " + currentRoomData.roomId;

        if (roomModeText != null)
            roomModeText.text = isVisitMode ? "VISITING" : "MY ROOM";

        if (isVisitMode)
            LockEditingForVisitor();

        Debug.Log($"[ROOM LOADER] Room:{currentRoomData.roomId} | Mode:{(isVisitMode ? "VISIT" : "OWNER")} | Objects:{currentRoomData.objects.Count} | Shelves:{currentRoomData.shelves.Count}");
    }

    public void OnRoomPortalPlaced(GameObject roomObject = null)
    {
        spawnedRoom = roomObject;
        if (currentRoomData == null) return;

        if (shelfPlacementController != null)
            shelfPlacementController.SetPortalRoom(spawnedRoom);

        // Restore shelves first
        if (currentRoomData.shelves != null && currentRoomData.shelves.Count > 0)
            shelfPlacementController?.RestoreShelves(currentRoomData.shelves, spawnedRoom);

        // Then restore objects
        if (currentRoomData.objects.Count > 0)
            StartCoroutine(RestoreObjectsCoroutine());
        else
            Debug.Log("[ROOM LOADER] No objects to restore.");
    }

    IEnumerator RestoreObjectsCoroutine()
    {
        yield return null;
        Debug.Log($"[ROOM LOADER] Restoring {currentRoomData.objects.Count} objects...");

        foreach (var objData in currentRoomData.objects)
        {
            yield return StartCoroutine(LoadAndPlaceObject(objData));
            yield return null;
        }

        Debug.Log("[ROOM LOADER] All objects restored.");
    }

    IEnumerator LoadAndPlaceObject(PlacedObjectData data)
    {
        if (glbFileLoader == null) { Debug.LogError("[ROOM LOADER] GlbFileLoader not assigned!"); yield break; }

        string filePath = Path.Combine(Application.persistentDataPath, "UploadedModels", data.fileName);
        if (!File.Exists(filePath)) { Debug.LogWarning($"[ROOM LOADER] File not found: {filePath}"); yield break; }

        bool loaded = false;
        GameObject loadedObj = null;

        glbFileLoader.LoadFile(filePath, (obj) => { loadedObj = obj; loaded = true; });

        float elapsed = 0f;
        while (!loaded && elapsed < 10f) { elapsed += Time.deltaTime; yield return null; }

        if (loadedObj == null) { Debug.LogWarning($"[ROOM LOADER] Load failed: {data.fileName}"); yield break; }

        // Parent to room and apply local position
        if (spawnedRoom != null)
        {
            loadedObj.transform.SetParent(spawnedRoom.transform);
            loadedObj.transform.localPosition = new Vector3(data.posX, data.posY, data.posZ);
            loadedObj.transform.localRotation = new Quaternion(data.rotX, data.rotY, data.rotZ, data.rotW);
            loadedObj.transform.localScale = new Vector3(data.scaleX, data.scaleY, data.scaleZ);
        }
        else
        {
            loadedObj.transform.position = new Vector3(data.posX, data.posY, data.posZ);
            loadedObj.transform.rotation = new Quaternion(data.rotX, data.rotY, data.rotZ, data.rotW);
            loadedObj.transform.localScale = new Vector3(data.scaleX, data.scaleY, data.scaleZ);
        }

        // Register with metadata restored from saved data
        if (objectPlacementController != null)
            objectPlacementController.RegisterRestoredObject(loadedObj, data.fileName, data);

        Debug.Log($"[ROOM LOADER] Restored: {data.fileName} | {data.objectName} | {(ObjectMetaData.ObjectType)data.objectType}");
    }

    void LockEditingForVisitor()
    {
        if (objectPlacementController != null)
        {
            objectPlacementController.HideBottomBar();
            objectPlacementController.SetVisitorMode(true);
        }
        if (shelfPlacementController != null)
            shelfPlacementController.SetVisitorMode(true);
    }
}