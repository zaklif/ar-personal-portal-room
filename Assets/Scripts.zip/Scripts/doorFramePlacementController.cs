﻿
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEngine.InputSystem.EnhancedTouch;
//using UnityEngine.XR.ARFoundation;
//using UnityEngine.XR.ARSubsystems;

//public class doorFramePlacementController : MonoBehaviour
//{
//    [SerializeField] private ARRaycastManager arRaycastManager;
//    [SerializeField] private ARPlaneManager arPlaneManager;

//    [Header("Room Templates")]
//    [SerializeField] private List<RoomTemplateData> roomTemplates = new List<RoomTemplateData>();
//    [SerializeField] private GameObject fallbackRoomPrefab;

//    [Header("Object Placement")]
//    [SerializeField] private ObjectPlacementController objectPlacementController;

//    private GameObject spawnedPortal;
//    private List<ARRaycastHit> hits = new List<ARRaycastHit>();
//    private bool portalPlaced = false;

//    void OnEnable() => EnhancedTouchSupport.Enable();
//    void OnDisable() => EnhancedTouchSupport.Disable();

//    void Update()
//    {
//        if (portalPlaced) return;

//        var activeTouches = UnityEngine.InputSystem.EnhancedTouch.Touch.activeTouches;
//        if (activeTouches.Count == 0) return;

//        var touch = activeTouches[0];
//        if (touch.phase != UnityEngine.InputSystem.TouchPhase.Began) return;

//        Vector2 touchPosition = touch.screenPosition;
//        bool raycastHit = arRaycastManager.Raycast(touchPosition, hits, TrackableType.PlaneWithinPolygon);

//        if (raycastHit)
//        {
//            SpawnPortal(hits[0].pose.position, hits[0].pose.rotation);
//        }
//        else
//        {
//            Debug.LogWarning("[PORTAL] Raycast missed — fallback spawn");
//            Vector3 camPos = Camera.main.transform.position;
//            Vector3 forward = Camera.main.transform.forward;
//            forward.y = 0; forward.Normalize();
//            Vector3 spawnPos = camPos + forward * 2f; spawnPos.y = 0f;
//            SpawnPortal(spawnPos, Quaternion.LookRotation(forward, Vector3.up));
//        }
//    }

//    void SpawnPortal(Vector3 pos, Quaternion rot)
//    {
//        Debug.Log("[PORTAL] SpawnPortal called");

//        // Pick room prefab from chosen template
//        string chosenTemplateName = PlayerPrefs.GetString("ChosenTemplateName", "");
//        RoomTemplateData chosenTemplate = FindTemplate(chosenTemplateName);

//        GameObject roomPrefabToSpawn;
//        Vector3 rotOffset;
//        float heightOffset;

//        if (chosenTemplate != null)
//        {
//            roomPrefabToSpawn = chosenTemplate.roomPrefab;
//            rotOffset = chosenTemplate.prefabRotationOffset;
//            heightOffset = chosenTemplate.spawnHeightOffset;
//            Debug.Log($"[PORTAL] Using template: {chosenTemplate.templateName}");
//        }
//        else
//        {
//            roomPrefabToSpawn = fallbackRoomPrefab;
//            rotOffset = new Vector3(90f, 180f, 0f);
//            heightOffset = 1.0f;
//            Debug.LogWarning($"[PORTAL] Template '{chosenTemplateName}' not found — using fallback.");
//        }

//        if (roomPrefabToSpawn == null)
//        {
//            Debug.LogError("[PORTAL] No room prefab available!");
//            return;
//        }

//        pos.y += heightOffset;
//        Quaternion finalRot = rot * Quaternion.Euler(rotOffset);

//        spawnedPortal = Instantiate(roomPrefabToSpawn, pos, finalRot);
//        portalPlaced = true;

//        // Hide AR plane visuals
//        if (arPlaneManager != null)
//        {
//            arPlaneManager.enabled = false;
//            foreach (var plane in arPlaneManager.trackables)
//                plane.gameObject.SetActive(false);
//        }

//        if (objectPlacementController == null)
//        {
//            Debug.LogError("[PORTAL] objectPlacementController is null!");
//            return;
//        }

//        objectPlacementController.SetPortalRoom(spawnedPortal);

//        // Fixed obsolete warning
//        FindFirstObjectByType<RoomLoader>()?.OnRoomPortalPlaced();

//        Debug.Log("[PORTAL] SpawnPortal complete!");
//    }

//    RoomTemplateData FindTemplate(string templateName)
//    {
//        if (string.IsNullOrEmpty(templateName)) return null;
//        foreach (var t in roomTemplates)
//            if (t != null && t.templateName == templateName)
//                return t;
//        return null;
//    }

//    public void ResetPortal()
//    {
//        if (spawnedPortal != null) Destroy(spawnedPortal);
//        portalPlaced = false;
//        if (arPlaneManager != null) arPlaneManager.enabled = true;
//        RoomInsideDetector.Reset();
//        Debug.Log("[PORTAL] Portal reset.");
//    }
//}

using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using System.Collections.Generic;
using UnityEngine.InputSystem.EnhancedTouch;

public class doorFramePlacementController : MonoBehaviour
{
    [SerializeField] private ARRaycastManager arRaycastManager;
    [SerializeField] private ARPlaneManager arPlaneManager;

    [Header("Room Templates")]
    [SerializeField] private List<RoomTemplateData> roomTemplates = new List<RoomTemplateData>();
    [SerializeField] private GameObject fallbackRoomPrefab;

    [Header("Object Placement")]
    [SerializeField] private ObjectPlacementController objectPlacementController;

    private GameObject spawnedPortal;
    private List<ARRaycastHit> hits = new List<ARRaycastHit>();
    private bool portalPlaced = false;

    void OnEnable() => EnhancedTouchSupport.Enable();
    void OnDisable() => EnhancedTouchSupport.Disable();

    void Update()
    {
        if (portalPlaced) return;

        var activeTouches = UnityEngine.InputSystem.EnhancedTouch.Touch.activeTouches;
        if (activeTouches.Count == 0) return;
        var touch = activeTouches[0];
        if (touch.phase != UnityEngine.InputSystem.TouchPhase.Began) return;

        bool raycastHit = arRaycastManager.Raycast(touch.screenPosition, hits, TrackableType.PlaneWithinPolygon);

        if (raycastHit)
            SpawnPortal(hits[0].pose.position, hits[0].pose.rotation);
        else
        {
            Vector3 camPos = Camera.main.transform.position;
            Vector3 forward = Camera.main.transform.forward; forward.y = 0; forward.Normalize();
            Vector3 spawnPos = camPos + forward * 2f; spawnPos.y = 0f;
            SpawnPortal(spawnPos, Quaternion.LookRotation(forward, Vector3.up));
        }
    }

    void SpawnPortal(Vector3 pos, Quaternion rot)
    {
        string chosenTemplateName = PlayerPrefs.GetString("ChosenTemplateName", "");
        RoomTemplateData chosenTemplate = FindTemplate(chosenTemplateName);

        GameObject roomPrefabToSpawn;
        Vector3 rotOffset;
        float heightOffset;

        if (chosenTemplate != null)
        {
            roomPrefabToSpawn = chosenTemplate.roomPrefab;
            rotOffset = chosenTemplate.prefabRotationOffset;
            heightOffset = chosenTemplate.spawnHeightOffset;
        }
        else
        {
            roomPrefabToSpawn = fallbackRoomPrefab;
            rotOffset = new Vector3(90f, 180f, 0f);
            heightOffset = 1.0f;
            Debug.LogWarning($"[PORTAL] Template '{chosenTemplateName}' not found — using fallback.");
        }

        if (roomPrefabToSpawn == null) { Debug.LogError("[PORTAL] No room prefab!"); return; }

        pos.y += heightOffset;
        spawnedPortal = Instantiate(roomPrefabToSpawn, pos, rot * Quaternion.Euler(rotOffset));
        portalPlaced = true;

        // Hide AR planes
        if (arPlaneManager != null)
        {
            arPlaneManager.enabled = false;
            foreach (var plane in arPlaneManager.trackables)
                plane.gameObject.SetActive(false);
        }

        objectPlacementController.SetPortalRoom(spawnedPortal);

        // FIX: Pass spawnedPortal to RoomLoader so it can parent objects to it
        FindFirstObjectByType<RoomLoader>()?.OnRoomPortalPlaced(spawnedPortal);

        Debug.Log("[PORTAL] SpawnPortal complete: " + spawnedPortal.name);
    }

    RoomTemplateData FindTemplate(string name)
    {
        if (string.IsNullOrEmpty(name)) return null;
        foreach (var t in roomTemplates)
            if (t != null && t.templateName == name) return t;
        return null;
    }

    public void ResetPortal()
    {
        if (spawnedPortal != null) Destroy(spawnedPortal);
        portalPlaced = false;
        if (arPlaneManager != null) arPlaneManager.enabled = true;
        RoomInsideDetector.Reset();
    }
}