﻿//using UnityEngine;
//using UnityEngine.UI;
//using TMPro;

///// <summary>
///// Panel shown to OWNER when they tap a placed object or during placement.
///// Lets them set: name, description, type (ViewOnly/ForSale), price.
/////
///// SETUP — Create this UI in Canvas:
///// OwnerSettingsPanel (Panel, set inactive)
///// ├── TitleText (TMP_Text)              "Object Settings"
///// ├── NameInputField (TMP_InputField)   "Object Name"
///// ├── DescInputField (TMP_InputField)   "Description (optional)"
///// ├── TypeToggleSection
///// │   ├── ViewOnlyButton (Button)       "👁 View Only"
///// │   └── ForSaleButton (Button)        "$ For Sale"
///// ├── PriceSection (GameObject)         hide if ViewOnly
///// │   ├── PriceLabel (TMP_Text)         "Price (MYR)"
///// │   └── PriceInputField (TMP_InputField)
///// ├── SaveButton (Button)               "Save"
///// └── CloseButton (Button)              "✕"
///// </summary>
//public class OwnerObjectSettings : MonoBehaviour
//{
//    [Header("Panel")]
//    [SerializeField] private GameObject settingsPanel;

//    [Header("Input Fields")]
//    [SerializeField] private TMP_InputField nameInputField;
//    [SerializeField] private TMP_InputField descInputField;
//    [SerializeField] private TMP_InputField priceInputField;

//    [Header("Type Toggle")]
//    [SerializeField] private Button viewOnlyButton;
//    [SerializeField] private Button forSaleButton;
//    [SerializeField] private Image viewOnlyButtonImage;
//    [SerializeField] private Image forSaleButtonImage;
//    [SerializeField] private GameObject priceSection;

//    [Header("Buttons")]
//    [SerializeField] private Button saveButton;
//    [SerializeField] private Button closeButton;

//    [Header("Colors")]
//    [SerializeField] private Color selectedColor = new Color(0.2f, 0.6f, 1f);
//    [SerializeField] private Color unselectedColor = new Color(0.4f, 0.4f, 0.4f);

//    // Current object being edited
//    private ObjectMetaData currentMeta;
//    private System.Action onSaved;

//    void Start()
//    {
//        settingsPanel.SetActive(false);

//        viewOnlyButton.onClick.AddListener(() => SetType(ObjectMetaData.ObjectType.ViewOnly));
//        forSaleButton.onClick.AddListener(() => SetType(ObjectMetaData.ObjectType.ForSale));
//        saveButton.onClick.AddListener(OnSavePressed);
//        closeButton.onClick.AddListener(Hide);
//    }

//    // ── Show settings for an object ───────────────────────────────────────

//    public void Show(ObjectMetaData meta, System.Action onSavedCallback = null)
//    {
//        currentMeta = meta;
//        onSaved = onSavedCallback;

//        // Fill fields with current values
//        nameInputField.text = meta.objectName;
//        descInputField.text = meta.description;
//        priceInputField.text = meta.price > 0 ? meta.price.ToString("F2") : "";

//        SetType(meta.objectType);
//        settingsPanel.SetActive(true);

//        Debug.Log($"[OWNER SETTINGS] Showing for: {meta.objectName}");
//    }

//    public void Hide()
//    {
//        settingsPanel.SetActive(false);
//        currentMeta = null;
//    }

//    // ── Type toggle ───────────────────────────────────────────────────────

//    void SetType(ObjectMetaData.ObjectType type)
//    {
//        if (currentMeta != null)
//            currentMeta.objectType = type;

//        bool isForSale = (type == ObjectMetaData.ObjectType.ForSale);

//        // Highlight selected button
//        viewOnlyButtonImage.color = isForSale ? unselectedColor : selectedColor;
//        forSaleButtonImage.color = isForSale ? selectedColor : unselectedColor;

//        // Show price section only if for sale
//        priceSection.SetActive(isForSale);
//    }

//    // ── Save ──────────────────────────────────────────────────────────────

//    void OnSavePressed()
//    {
//        if (currentMeta == null) return;

//        // Validate name
//        string newName = nameInputField.text.Trim();
//        if (string.IsNullOrEmpty(newName))
//        {
//            nameInputField.text = "My Object";
//            newName = "My Object";
//        }

//        currentMeta.objectName = newName;
//        currentMeta.description = descInputField.text.Trim();

//        // Parse price
//        if (currentMeta.IsForSale)
//        {
//            if (float.TryParse(priceInputField.text, out float parsedPrice))
//                currentMeta.price = Mathf.Max(0f, parsedPrice);
//            else
//                currentMeta.price = 0f;
//        }
//        else
//        {
//            currentMeta.price = 0f;
//        }

//        // Refresh the floating indicator
//        currentMeta.RefreshIndicator();

//        // Save to room data
//        SaveMetaToRoom();

//        Debug.Log($"[OWNER SETTINGS] Saved: {currentMeta.objectName} | {currentMeta.objectType} | {currentMeta.price}");

//        Hide();
//        onSaved?.Invoke();
//    }

//    void SaveMetaToRoom()
//    {
//        if (RoomManager.Instance == null || !RoomManager.IsOwner) return;
//        RoomManager.Instance.UpdateObjectMeta(currentMeta);
//    }
//}

using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class OwnerObjectSettings : MonoBehaviour
{
    [Header("Panel")]
    [SerializeField] private GameObject settingsPanel;

    [Header("Input Fields")]
    [SerializeField] private TMP_InputField nameInputField;
    [SerializeField] private TMP_InputField descInputField;
    [SerializeField] private TMP_InputField priceInputField;

    [Header("Type Toggle")]
    [SerializeField] private Button viewOnlyButton;
    [SerializeField] private Button forSaleButton;
    [SerializeField] private Image viewOnlyButtonImage;
    [SerializeField] private Image forSaleButtonImage;
    [SerializeField] private GameObject priceSection;

    [Header("Buttons")]
    [SerializeField] private Button saveButton;
    [SerializeField] private Button closeButton;

    [Header("Colors")]
    [SerializeField] private Color selectedColor = new Color(0.2f, 0.6f, 1f);
    [SerializeField] private Color unselectedColor = new Color(0.4f, 0.4f, 0.4f);

    private ObjectMetaData currentMeta;
    private System.Action onSaved;

    // FIX: track if panel was explicitly opened to prevent accidental shows
    private bool isOpen = false;

    void Start()
    {
        settingsPanel.SetActive(false);
        viewOnlyButton.onClick.AddListener(() => SetType(ObjectMetaData.ObjectType.ViewOnly));
        forSaleButton.onClick.AddListener(() => SetType(ObjectMetaData.ObjectType.ForSale));
        saveButton.onClick.AddListener(OnSavePressed);
        closeButton.onClick.AddListener(Hide);
    }

    public bool IsOpen => isOpen;

    // FIX: only open when explicitly called — never auto-opens
    public void Show(ObjectMetaData meta, System.Action onSavedCallback = null)
    {
        // Extra safety — must be owner
        if (!RoomManager.IsOwner)
        {
            Debug.LogWarning("[OWNER SETTINGS] Not owner — cannot open settings.");
            return;
        }

        currentMeta = meta;
        onSaved = onSavedCallback;

        nameInputField.text = meta.objectName;
        descInputField.text = meta.description;
        priceInputField.text = meta.price > 0 ? meta.price.ToString("F2") : "";

        // Refresh type buttons to match current state
        RefreshTypeButtons(meta.objectType);

        isOpen = true;
        settingsPanel.SetActive(true);

        Debug.Log($"[OWNER SETTINGS] Showing for: {meta.objectName} | type={meta.objectType}");
    }

    public void Hide()
    {
        isOpen = false;
        settingsPanel.SetActive(false);
        currentMeta = null;
    }

    void SetType(ObjectMetaData.ObjectType type)
    {
        if (currentMeta != null)
            currentMeta.objectType = type;

        RefreshTypeButtons(type);
    }

    void RefreshTypeButtons(ObjectMetaData.ObjectType type)
    {
        bool isForSale = (type == ObjectMetaData.ObjectType.ForSale);
        viewOnlyButtonImage.color = isForSale ? unselectedColor : selectedColor;
        forSaleButtonImage.color = isForSale ? selectedColor : unselectedColor;
        priceSection.SetActive(isForSale);
    }

    void OnSavePressed()
    {
        if (currentMeta == null)
        {
            Debug.LogWarning("[OWNER SETTINGS] Save pressed but currentMeta is null!");
            return;
        }

        string newName = nameInputField.text.Trim();
        currentMeta.objectName = string.IsNullOrEmpty(newName) ? "My Object" : newName;
        currentMeta.description = descInputField.text.Trim();

        if (currentMeta.IsForSale)
        {
            if (float.TryParse(priceInputField.text, out float p))
                currentMeta.price = Mathf.Max(0f, p);
            else
                currentMeta.price = 0f;
        }
        else
        {
            currentMeta.price = 0f;
        }

        currentMeta.RefreshIndicator();

        // Save to room using instanceId for reliable lookup
        if (RoomManager.Instance != null && RoomManager.IsOwner)
            RoomManager.Instance.UpdateObjectMeta(currentMeta);

        Debug.Log($"[OWNER SETTINGS] Saved: {currentMeta.objectName} | {currentMeta.objectType} | {currentMeta.price} | id={currentMeta.instanceId}");

        Hide();
        onSaved?.Invoke();
    }
}