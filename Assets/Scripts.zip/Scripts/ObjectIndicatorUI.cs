﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// Floating world-space indicator above each placed object.
/// Shows $ for ForSale, 👁 for ViewOnly.
///
/// SETUP:
/// 1. Create a prefab called "ObjectIndicatorPrefab":
///    - Root: Canvas (World Space, scale 0.002, 0.002, 0.002)
///    - Child: Panel (small, e.g. 80x40)
///      - IconText (TMP_Text) — shows "$" or "👁"
///      - BgImage (Image) — background color
/// 2. Assign this prefab to ObjectPlacementController → Indicator Prefab
///
/// The indicator always faces the camera (billboarding).
/// </summary>
public class ObjectIndicatorUI : MonoBehaviour
{
    [Header("UI References")]
    [SerializeField] private TMP_Text iconText;
    [SerializeField] private Image backgroundImage;

    [Header("Colors")]
    [SerializeField] private Color forSaleColor = new Color(0.2f, 0.8f, 0.2f, 0.9f);   // green
    [SerializeField] private Color viewOnlyColor = new Color(0.2f, 0.5f, 1f, 0.9f);    // blue

    [Header("Position")]
    [SerializeField] private float heightOffset = 0.3f; // how high above object

    private Transform targetObject; // the object this indicator belongs to
    private Camera arCamera;

    void Start()
    {
        arCamera = Camera.main;
    }

    void LateUpdate()
    {
        if (targetObject == null) return;

        // Float above the object
        transform.position = targetObject.position + Vector3.up * heightOffset;

        // Always face camera (billboard effect)
        if (arCamera != null)
            transform.LookAt(arCamera.transform);
    }

    public void SetTarget(Transform obj)
    {
        targetObject = obj;
    }

    public void Refresh(ObjectMetaData meta)
    {
        if (meta.IsForSale)
        {
            iconText.text = "$";
            backgroundImage.color = forSaleColor;
        }
        else
        {
            iconText.text = "👁";
            backgroundImage.color = viewOnlyColor;
        }
    }
}