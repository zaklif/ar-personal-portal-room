﻿//using UnityEngine;
//using UnityEngine.Events;
//using TMPro;

///// <summary>
///// DEBUG VERSION - shows on screen what is happening.
///// Replace with clean version once confirmed working.
///// </summary>
//public class RoomInsideDetector : MonoBehaviour
//{
//    [Header("Settings")]
//    [SerializeField] private string cameraTag = "MainCamera";

//    [Header("Events")]
//    public UnityEvent onPlayerEntered;
//    public UnityEvent onPlayerExited;

//    [Header("DEBUG — assign a TMP Text on your Canvas to see status on phone")]
//    [SerializeField] private TMP_Text debugText;

//    public static bool IsInsideRoom { get; private set; } = false;

//    void Start()
//    {
//        // ── Check 1: Is the collider set up? ──────────────────────────────
//        Collider col = GetComponent<Collider>();
//        if (col == null)
//        {
//            Debug.LogError("[ROOM] NO COLLIDER on this GameObject! Add a Box Collider with Is Trigger ticked.");
//            SetDebugText("NO COLLIDER!");
//            return;
//        }

//        if (!col.isTrigger)
//        {
//            Debug.LogError("[ROOM] Collider IS NOT a trigger! Tick 'Is Trigger' on the Box Collider.");
//            SetDebugText("NOT A TRIGGER!");
//            return;
//        }

//        Debug.Log($"[ROOM] Collider OK — size={col.bounds.size}");

//        // ── Check 2: Can we find the camera? ──────────────────────────────
//        GameObject cam = GameObject.FindWithTag(cameraTag);
//        if (cam == null)
//        {
//            Debug.LogError($"[ROOM] No GameObject with tag '{cameraTag}' found! " +
//                           "Go to XR Origin > Camera Offset > Main Camera and check its Tag at the top of Inspector.");
//            SetDebugText($"NO CAM TAG '{cameraTag}'");
//            return;
//        }

//        Debug.Log($"[ROOM] Camera found: '{cam.name}' tag='{cam.tag}'");

//        // ── Fix 3: Camera needs a Collider for trigger detection ───────────
//        Collider camCol = cam.GetComponent<Collider>();
//        if (camCol == null)
//        {
//            // Auto-add a tiny sphere collider to the camera
//            SphereCollider sc = cam.AddComponent<SphereCollider>();
//            sc.radius = 0.1f;
//            sc.isTrigger = false; // must NOT be trigger — room collider is the trigger
//            Debug.Log("[ROOM] Auto-added Sphere Collider to camera.");
//            SetDebugText("Added collider to camera");
//        }

//        // ── Fix 4: One of the objects needs a Rigidbody for trigger to fire ─
//        // Best practice: put Rigidbody on the camera (kinematic)
//        Rigidbody rb = cam.GetComponent<Rigidbody>();
//        if (rb == null)
//        {
//            Rigidbody newRb = cam.AddComponent<Rigidbody>();
//            newRb.isKinematic = true;  // kinematic = physics won't move it
//            newRb.useGravity = false;
//            Debug.Log("[ROOM] Auto-added kinematic Rigidbody to camera.");
//        }

//        SetDebugText("Ready — walk into room!");
//        Debug.Log("[ROOM] Setup complete. Walk into the room trigger.");
//    }

//    private void OnTriggerEnter(Collider other)
//    {
//        // This logs ANYTHING that enters — helps debug what tag is being detected
//        Debug.Log($"[ROOM] OnTriggerEnter — object='{other.gameObject.name}' tag='{other.tag}'");

//        if (!other.CompareTag(cameraTag))
//        {
//            Debug.Log($"[ROOM] Ignored — expected tag '{cameraTag}' but got '{other.tag}'");
//            return;
//        }

//        IsInsideRoom = true;
//        Debug.Log("[ROOM] INSIDE ROOM — editing unlocked!");
//        SetDebugText("INSIDE ROOM");
//        onPlayerEntered?.Invoke();
//    }

//    private void OnTriggerExit(Collider other)
//    {
//        Debug.Log($"[ROOM] OnTriggerExit — object='{other.gameObject.name}' tag='{other.tag}'");

//        if (!other.CompareTag(cameraTag))
//            return;

//        IsInsideRoom = false;
//        Debug.Log("[ROOM] OUTSIDE ROOM — editing locked.");
//        SetDebugText("OUTSIDE ROOM");
//        onPlayerExited?.Invoke();
//    }

//    void SetDebugText(string msg)
//    {
//        if (debugText != null)
//            debugText.text = $"[ROOM] {msg}";
//    }

//    public static void Reset()
//    {
//        IsInsideRoom = false;
//    }
//}

using UnityEngine;
using TMPro;

/// <summary>
/// Attach to your room prefab root.
/// NO manual wiring needed — finds ShelfPlacementController automatically at runtime.
/// </summary>
public class RoomInsideDetector : MonoBehaviour
{
    [Header("Settings")]
    [SerializeField] private string cameraTag = "MainCamera";

    [Header("DEBUG — optional, assign a TMP Text to see status on phone")]
    [SerializeField] private TMP_Text debugText;

    public static bool IsInsideRoom { get; private set; } = false;

    // Found automatically at runtime
    private ShelfPlacementController shelfController;
    private GameObject arCamera;

    void Start()
    {
        // ── Auto-find ShelfPlacementController in the scene ───────────────
        shelfController = FindFirstObjectByType<ShelfPlacementController>();
        if (shelfController == null)
            Debug.LogError("[ROOM] ShelfPlacementController not found! Make sure it's on XR Origin.");
        else
            Debug.Log("[ROOM] ShelfPlacementController found automatically.");

        // ── Auto-find AR Camera by tag ────────────────────────────────────
        arCamera = GameObject.FindWithTag(cameraTag);
        if (arCamera == null)
        {
            Debug.LogError($"[ROOM] No camera with tag '{cameraTag}' found! " +
                           "Check XR Origin > Camera Offset > Main Camera tag.");
            SetDebugText($"NO CAM TAG '{cameraTag}'");
            return;
        }
        Debug.Log($"[ROOM] Camera found: '{arCamera.name}'");

        // ── Auto-add Sphere Collider to camera if missing ─────────────────
        // Unity trigger detection requires the entering object to have a collider
        if (arCamera.GetComponent<Collider>() == null)
        {
            SphereCollider sc = arCamera.AddComponent<SphereCollider>();
            sc.radius = 0.1f;
            sc.isTrigger = false;
            Debug.Log("[ROOM] Auto-added Sphere Collider to camera.");
        }

        // ── Auto-add Rigidbody to camera if missing ───────────────────────
        // Unity trigger detection requires at least one Rigidbody between the two objects
        if (arCamera.GetComponent<Rigidbody>() == null)
        {
            Rigidbody rb = arCamera.AddComponent<Rigidbody>();
            rb.isKinematic = true;   // kinematic = physics won't affect the camera
            rb.useGravity = false;
            Debug.Log("[ROOM] Auto-added kinematic Rigidbody to camera.");
        }

        // ── Check this room's collider ────────────────────────────────────
        Collider col = GetComponent<Collider>();
        if (col == null)
        {
            Debug.LogError("[ROOM] No Box Collider on room prefab root! Add one and tick Is Trigger.");
            SetDebugText("NO COLLIDER ON ROOM!");
            return;
        }
        if (!col.isTrigger)
        {
            Debug.LogError("[ROOM] Box Collider on room is NOT a trigger! Tick 'Is Trigger'.");
            SetDebugText("COLLIDER NOT TRIGGER!");
            return;
        }

        SetDebugText("Ready — walk into room!");
        Debug.Log("[ROOM] Setup complete!");
    }

    private void OnTriggerEnter(Collider other)
    {
        Debug.Log($"[ROOM] OnTriggerEnter — '{other.gameObject.name}' tag='{other.tag}'");

        if (!other.CompareTag(cameraTag)) return;

        IsInsideRoom = true;
        Debug.Log("[ROOM] INSIDE ROOM — editing unlocked!");
        SetDebugText("INSIDE ROOM");

        CustomRoomSetupUI ui = Object.FindFirstObjectByType<CustomRoomSetupUI>();

        if (ui != null && RoomManager.IsOwner)
        {
            ui.SetOwnerInside(true);
        }

        

        // Call ShelfPlacementController directly — no Inspector wiring needed
        if (shelfController != null)
            shelfController.OnEnteredRoom();
    }

    private void OnTriggerExit(Collider other)
    {
        Debug.Log($"[ROOM] OnTriggerExit — '{other.gameObject.name}' tag='{other.tag}'");

        if (!other.CompareTag(cameraTag)) return;

        IsInsideRoom = false;
        Debug.Log("[ROOM] OUTSIDE ROOM — editing locked.");
        SetDebugText("OUTSIDE ROOM");

        CustomRoomSetupUI ui = Object.FindFirstObjectByType<CustomRoomSetupUI>();

        if (ui != null)
        {
            ui.SetOwnerInside(false);
        }


        //likeyellowroom
        

        // Call ShelfPlacementController directly — no Inspector wiring needed
        if (shelfController != null)
            shelfController.OnExitedRoom();
    }

    void SetDebugText(string msg)
    {
        if (debugText != null)
            debugText.text = $"[ROOM] {msg}";
    }

    public static void Reset()
    {
        IsInsideRoom = false;
    }
}